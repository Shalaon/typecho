<?php
/*
 * 付费阅读微信异步回调
 */
include '../../../config.inc.php';
require_once 'libs/payjs.php';
date_default_timezone_set('Asia/Shanghai');

$db = Typecho_Db::get();

//获取支付相关的配置参数
$paySql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"pay");
$paySqlRows = $db->fetchAll($paySql);

$key = array_column($paySqlRows, 'cfg_key');
$value = array_column($paySqlRows, 'cfg_value');

$payRows = array_combine($key, $value);

$data = $_POST;
if($data['return_code'] == 1){
	$payjs = new Payjs("","",$payRows['payjs_wxpay_mchkey'],"");
	$sign_verify = $data['sign'];
	unset($data['sign']);
	//if($payjs->sign($data) == $sign_verify&&$data['total_fee']==$data['attach']*100){
	if($payjs->sign($data) == $sign_verify){		
		$queryItem= $db->select()->from('table.tepass_fees')->where('fee_id=?',$_POST['out_trade_no']); 
		$rowFee = $db->fetchRow($queryItem);
		if(!empty($rowFee)){
			if($rowFee['fee_status'] < 1){
				if(strlen($rowFee["fee_id"]) == 16){//小于这个数字的就是购买VIP会员
					//去查询一下用户的状态，从而决定是购买还是续费。
					$rowVip= $db->fetchRow($db->select()->from('table.tepass_vips')->where('vip_uid=?',$rowFee["fee_uid"])); 
					if($rowVip["vip_status"] > 0){
						//用户本身就是会员，并且没有到期，那么就是续费
						$newendtime = (int)$rowFee["fee_total_days"]*24*60*60 + (int)$rowVip["vip_endtime"];
						
						//购买月会员状态加1，年会员就加12				
						if($rowFee["fee_total_days"] == "31"){
							$vip_status = $rowVip["vip_status"] + 1;
						}elseif($rowFee["fee_total_days"] == "366"){
							$vip_status = $rowVip["vip_status"] + 12;
						}else{
							$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"months_for_upgrade_eternal")->limit(1));
							$vip_status = (int)$rsconfig['cfg_value'];//终身会员
						}
						$updateEndtime = $db->update('table.tepass_vips')->rows(array('vip_endtime'=>(int)$newendtime,'vip_status'=>$vip_status))->where('vip_uid=?',$rowFee["fee_uid"]);
						$updateEndtimeRows= $db->query($updateEndtime);
					}else{
						//用户本身不是VIP会员，那么就是新购买
						$newendtime = (int)$rowFee["fee_total_days"]*24*60*60 + time();		
						
						//购买月会员状态加1，年会员就加12				
						if($rowFee["fee_total_days"] == "31"){
							$vip_status = 1;
						}elseif($rowFee["fee_total_days"] == "366"){
							$vip_status = 12;
						}else{
							$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"months_for_upgrade_eternal")->limit(1));
							$vip_status = (int)$rsconfig['cfg_value'];//终身会员
						}
						$updateEndtime = $db->update('table.tepass_vips')->rows(array('vip_endtime'=>(int)$newendtime,'vip_status'=>$vip_status))->where('vip_uid=?',$rowFee["fee_uid"]);
						$updateEndtimeRows= $db->query($updateEndtime);			
					}
					//修改订单状态为checked
					$updateFeeCheck = $db->update('table.tepass_fees')->rows(array('fee_check'=>"checked"))->where('fee_id=?',$rowFee["fee_id"]);
					$updateFeeCheckRows= $db->query($updateFeeCheck);
				}else{
					//******感谢规则之树https://www.ruletree.club/，在0.5.0版本加入文章发布者账户收益功能******
					//通过文章id获取作者id
					$selectPost = $db->select()->from('table.contents')->where('cid=?',$rowFee["fee_cid"])->limit(1); 
					$postRows = $db->fetchRow($selectPost);
					
					//通过作者id查询余额并累加
					$selectUser = $db->select()->from('table.tepass_vips')->where('vip_uid=?',$postRows['authorId'])->limit(1);
					$userRows = $db->fetchRow($selectUser);
					$addAmount = $rowFee["fee_total_price"] * 100;
					$u_points = (int)$userRows['vip_points'] + (int)$addAmount;//文章收益
					$u_money = (int)$u_points + (int)$userRows['vip_total_ref_income'];
					
					$updateUser = $db->update('table.tepass_vips')->rows(array('vip_points'=>(int)$u_points, 'vip_money'=>(int)$u_money))->where('vip_uid=?',$postRows['authorId']);
					$updateUserRows= $db->query($updateUser);	
					//******文章发布收益算账结束******
					
					//修改订单状态为checked
					$updateFeeCheck = $db->update('table.tepass_fees')->rows(array('fee_check'=>"checked"))->where('fee_id=?',$rowFee["fee_id"]);
					$updateFeeCheckRows= $db->query($updateFeeCheck);
					
					//更新文章付费总数
					$queryPost= $db->select()->from('table.tepass_fees')->where('fee_id=?',$_POST['out_trade_no']); 
					$rowFeeCid = $db->fetchRow($queryPost);	
					$cidnumsql = $db->select()->from('table.tepass_fees')->where('table.tepass_fees.fee_cid=?',$rowFeeCid["fee_cid"])->where('table.tepass_fees.fee_status=1');
					$rowcidnumsql = $db->fetchAll($cidnumsql);
					if(count($rowcidnumsql) > 0){
						$post_sold_num = count($rowcidnumsql);
					}else{
						$post_sold_num = 0;
					}		
					$updatePostSoldNum = $db->update('table.tepass_posts')->rows(array('post_sold_num'=>$post_sold_num))->where('post_id=?',$rowFeeCid["fee_cid"]);
					$updatePostSoldNumRows= $db->query($updatePostSoldNum);	
					//******发布付款成功通知给文章作者******
					//利用Server酱推送到微信
					if(!empty($userRows['vip_sckey'])){		
						file_get_contents('https://sc.ftqq.com/'.$userRows['vip_sckey'].'.send?text='.urlencode($rowFee['fee_title']).'&desp='.urlencode('订单号：'.$_POST['out_trade_no'].'

	微信付款：'.$_POST['attach'].'元'));
					}	
				}
				//处理你的逻辑，例如获取订单号$_POST['out_trade_no']，订单金额$_POST['total_amount']等
				$updateItem = $db->update('table.tepass_fees')->rows(array('fee_status'=>1))->where('fee_id=?',$_POST['out_trade_no']);
				$updateItemRows= $db->query($updateItem);
				
				//利用Server酱推送到微信
				if(!empty($payRows['server_chan_sckey'])){		
					file_get_contents('https://sc.ftqq.com/'.$payRows['server_chan_sckey'].'.send?text='.urlencode($rowFee['fee_title']).'&desp='.urlencode('订单号：'.$_POST['out_trade_no'].'

	微信付款：'.$_POST['attach'].'元'));
				}
				
				echo 'success';	
				exit();	
			}
		}
	}else{
		$db = Typecho_Db::get();
		$updateItem = $db->update('table.tepass_fees')->rows(array('fee_status'=>2))->where('fee_id=?',$_POST['out_trade_no']);
		$updateItemRows= $db->query($updateItem);
		echo 'fail';
		exit();
	}
}else{
	echo 'error';
	exit();
}

?>