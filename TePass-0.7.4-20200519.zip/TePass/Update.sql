INSERT IGNORE INTO `typecho_tepass_configs` (`cfg_id`, `cfg_name`, `cfg_key`, `cfg_type`, `cfg_value`, `cfg_desc`, `cfg_intime`) VALUES
(23, '个人中心通知', 'for_my_center', 'notice', '', '个人中心通知', '2020-02-12 00:00:00'),
(24, '技术支持说明', 'for_support', 'notice', '', '技术支持说明', '2020-02-12 00:00:00'),
(25, 'QQ登录', 'qq_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(26, '微博登录', 'weibo_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(27, 'GitHub登录', 'github_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(28, '微信登录', 'wechat_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(29, '连续续费的月数', 'months_for_upgrade_eternal', 'vvip', '60', '连续续费到这个月数，可以升级为终身会员，默认60，建议在插件启用就修改，后面不能改。', '2020-02-12 00:00:00'),
(30, '新注册用户默认分组', 'default_register_group', 'sign', 'subscriber', '管理员：administrator，编辑：editor，贡献者：contributor，关注者：subscriber，访问者：visitor。', '2020-02-12 00:00:00'),
(31, '订单查询', 'search_order', 'order', '0', '所有人可查：0，登录用户可查：1，VIP会员可查：2。', '2020-03-07 00:00:00'),
(32, '静态资源', 'css_js', 'static', 'local', '使用本地资源：local，CDN资源：cdn。', '2020-03-12 00:00:00'),
(33, '发布资源收益', 'for_post_contribute', 'post', '', '发布资源收益，填写发布地址，默认为空，不显示，谁发布的资源，收益就在谁账户。', '2020-03-12 00:00:00'),
(34, '二维码生成接口', 'for_qrcode', 'qrcode', '', '不填写，默认调用本地接口，也可以自己去找可用的公共接口。', '2020-03-31 00:00:00'),
(35, '点击付款次数限制', 'for_click_limit', 'click', '30', '同一IP在30分钟内点击付款最多次数，默认30次。', '2020-04-16 00:00:00'),
(36, '个人中心地址', 'user_center_url', 'url', '', '个人中心地址，登录注册购买会员后跳转地址，不填默认跳到后台个人中心。', '2020-05-07 00:00:00');
UPDATE `typecho_tepass_configs` SET `cfg_name`="个人中心通知",`cfg_desc`="个人中心通知" WHERE `cfg_id`=23;
UPDATE `typecho_tepass_configs` SET `cfg_name`="技术支持说明",`cfg_desc`="技术支持说明" WHERE `cfg_id`=24;
UPDATE `typecho_tepass_configs` SET `cfg_name`="QQ登录",`cfg_desc`="格式：appid---appsecret---callbackurl" WHERE `cfg_id`=25;
UPDATE `typecho_tepass_configs` SET `cfg_name`="微博登录",`cfg_desc`="格式：appid---appsecret---callbackurl" WHERE `cfg_id`=26;
UPDATE `typecho_tepass_configs` SET `cfg_name`="GitHub登录",`cfg_desc`="格式：appid---appsecret---callbackurl" WHERE `cfg_id`=27;
UPDATE `typecho_tepass_configs` SET `cfg_name`="微信登录",`cfg_desc`="输入payjs的商户ID即可" WHERE `cfg_id`=28;
UPDATE `typecho_tepass_configs` SET `cfg_desc`="发布资源收益，填写发布地址，默认为空，不显示，谁发布的资源，收益就在谁账户。" WHERE `cfg_id`=33;
UPDATE `typecho_tepass_configs` SET `cfg_name`="个人中心地址",cfg_key="user_center_url",cfg_desc="个人中心地址，登录注册购买会员后跳转地址，不填默认跳到后台个人中心。" WHERE `cfg_id`=36;
ALTER TABLE `typecho_tepass_fees` ADD `fee_user_agent` varchar(255) DEFAULT NULL COMMENT '提交订单的客户端';	
ALTER TABLE `typecho_tepass_vips` CHANGE vip_website vip_sckey VARCHAR(255) DEFAULT NULL COMMENT 'Server酱秘钥';
ALTER TABLE `typecho_tepass_posts` ADD `post_uid` INT(10) NULL DEFAULT '1' AFTER `post_id`;