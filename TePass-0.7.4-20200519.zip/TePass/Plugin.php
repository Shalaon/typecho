<?php
/**
 * TePassForTypecho<a href="http://forum.typecho.org/viewtopic.php?f=6&t=12265" style="color:red;">付费阅读插件</a>
 * @package TePass For Typecho
 * @author 胖蒜网
 * @version 0.7.4
 * @link https://store.pangsuan.com/p/tepass.html
 * @date 2020-02-01
 * @支付宝接口排查地址：https://openmonitor.alipay.com/acceptance/cloudparse.htm
 */
class TePass_Plugin extends Widget_Abstract_Users implements Typecho_Plugin_Interface{
    // 激活插件
    public static function activate(){
		require_once('libs/activate.php');
		//后台编辑文章插入
        Typecho_Plugin::factory('admin/footer.php')->end = array('TePass_Plugin', 'footerjs');
		Typecho_Plugin::factory('admin/menu.php')->navBar = array('TePass_Plugin', 'render');
		Typecho_Plugin::factory('admin/write-post.php')->bottom = array('TePass_Plugin', 'forTePassToolbar');
		Typecho_Plugin::factory('admin/write-page.php')->bottom = array('TePass_Plugin', 'forTePassToolbar');
		Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('TePass_Plugin', 'contentEx');
		Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('TePass_Plugin', 'excerptEx');
		Typecho_Plugin::factory('admin/write-post.php')->option = array(__CLASS__, 'setFeeContent');
		Typecho_Plugin::factory('Widget_Contents_Post_Edit')->finishPublish = array(__CLASS__, "updateFeeContent");
		Typecho_Plugin::factory('admin/write-page.php')->option = array(__CLASS__, 'setFeeContent');
		Typecho_Plugin::factory('Widget_Contents_Page_Edit')->finishPublish = array(__CLASS__, "updateFeeContent");
		Helper::addRoute('tepass_refresh', '/tepass/refresh', 'TePass_Action', 'forRefresh');
    }   
	public static function render()
    {
        echo '<span class="message" target="_self" style="background-color:red;color:white;cursor:pointer;" onclick="window.location=\'extending.php?panel=TePass/theme/ucenter/profile.php&status=buy\'">购买VIP会员</span>';
    }
	public static function footerjs()
    {
		$user=Typecho_Widget::widget('Widget_User');
		$email =$user->mail;
		if($email){
			$smail=strtolower($email);
			$f=str_replace('@qq.com','',$smail);
			if(strstr($smail,"qq.com")&&is_numeric($f)&&strlen($f)<11&&strlen($f)>4){
				$navatar= '//q1.qlogo.cn/g?b=qq&nk='.$f.'&s=640';
			}else{
				$d=md5($smail);
				$navatar="https://cdn.v2ex.com/gravatar/".$d."?s=220&d=identicon";
			}
		}else{
			$navatar= '/usr/plugins/TePass/static/default_avatar.jpg';
		} 
		
		echo '<script>
		var UserPic = "'.$navatar.'";
		var avatar = document.getElementsByClassName("profile-avatar")[0];
		if(avatar){
			avatar.setAttribute("src",UserPic);
			avatar.style.width="220px";
		}
		</script>';
	}
    // 禁用插件
    public static function deactivate(){
		$index = Helper::removeMenu('TePass');		
		Helper::removeAction('tepass-for-action');
		Helper::removePanel($index, 'TePass/theme/admin/config.php');
		Helper::removePanel($index, 'TePass/theme/admin/vips.php');
		Helper::removePanel($index, 'TePass/theme/admin/posts.php');
		Helper::removePanel($index, 'TePass/theme/admin/forcheck.php');
		Helper::removePanel($index, 'TePass/theme/admin/feeslist.php');
		Helper::removePanel($index, 'TePass/theme/admin/delete.php');
		$ucenter = Helper::removeMenu('会员中心');	
		Helper::removePanel($ucenter, 'TePass/theme/ucenter/profile.php');
		Helper::removePanel($ucenter, 'TePass/theme/ucenter/fees.php');
		Helper::removePanel($ucenter, 'TePass/theme/ucenter/sold.php');
		Helper::removePanel($ucenter, 'TePass/theme/ucenter/withdraw.php');
        Helper::removeRoute('tepass_order');
        Helper::removeRoute('tepass_signin');
        Helper::removeRoute('tepass_signup');
        Helper::removeRoute('tepass_forgot');
        Helper::removeRoute('tepass_reset');
        Helper::removeRoute('tepass_qq_login');
        Helper::removeRoute('tepass_wb_login');
        Helper::removeRoute('tepass_gh_login');
        Helper::removeRoute('tepass_wx_login');
        Helper::removeRoute('tepass_wx_login_end');
        Helper::removeRoute('tepass_notice');
        Helper::removeRoute('tepass_refresh');
        Helper::removeRoute('ref');
        return _t('插件已被禁用');
    }

    public static function config(Typecho_Widget_Helper_Form $form) {}
	
    // 个人用户配置面板
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    // 获得插件配置信息
    public static function getConfig(){
        return Typecho_Widget::widget('Widget_Options')->plugin('TePass');
    }
	/**
     * 输出头部或底部css,js等
     *
     * @access public
     * @param unknown $header
     * @return unknown
     */
    public static function header(){}

	public static function footer(){}
	
	private static function Judge_Database(){
        $db= Typecho_Db::get();
        $getAdapterName = $db->getAdapterName();
        if(preg_match('/^M|m?ysql$/',$getAdapterName)){
            return true;
        }else{
            throw new Typecho_Plugin_Exception(_t('对不起，仅支持mysql数据库。'));
        }
    }
	
	/*创建支付订单数据表*/
	public static function createTableTePass($installDb){
		$prefix = $installDb->getPrefix();
		$scripts = file_get_contents('usr/plugins/TePass/Mysql.sql');
		$scripts = str_replace('typecho_', $prefix, $scripts);
		$scripts = explode(';', $scripts);		
		try {
			foreach ($scripts as $script) {
				$script = trim($script);
				if ($script) {
					$installDb->query($script, Typecho_Db::WRITE);
				}
			}
			return _t('插件已经激活，需先配置插件信息！');
		} catch (Exception $e) {
            print_r($e);
			$code = $e->getCode();
			try {
				$script = 'SELECT `cfg_id`, `cfg_name`, `cfg_key`, `cfg_type`, `cfg_value`, `cfg_desc`, `cfg_intime` from `' . $prefix . 'tepass_configs`';
				$installDb->query($script, Typecho_Db::READ);
				return '检测到数据表，插件启用成功';				
			} catch (Typecho_Db_Exception $e) {
				return TePass_Plugin::deactivate();
				throw new Typecho_Plugin_Exception('插件启用失败。错误号：'.$code);
			}
		}	
	}

	public static function forsignup($v) {
		$db=Typecho_Db::get ();
		$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"default_register_group")->limit(1));
		if(!empty($rsconfig)){
			$register_group = $rsconfig['cfg_value'];
		}else{
			$register_group = "subscriber";
		}		
		//以下代码参考：https://github.com/jrotty/Rdog
		$hasher = new PasswordHash(8, true);//调用系统的生成密码
		/*判断注册表单是否有密码*/
		if(isset(Typecho_Widget::widget('Widget_Register')->request->password)){
			/*将密码设定为用户输入的密码*/
			$generatedPassword = Typecho_Widget::widget('Widget_Register')->request->password;
		}else{
			/*用户没输入密码，随机密码*/
			$generatedPassword = Typecho_Common::randString(7);
		}
		/*将密码设置为常量，方便下个函数adu()直接获取*/
		define('passd', $generatedPassword);
		/*将密码加密*/
		$wPassword = $hasher->HashPassword($generatedPassword);
		/*设置用户密码*/
		$v['password'] = $wPassword;
		/*将注册用户默认用户组改为插件设置的用户组*/

		$v['group'] = $register_group;
		/*返回注册参数*/
		return $v;
	}
	
	public static function forsignupend($obj) {
		/*获取密码*/
		$wPassword=passd;
		$obj->user->login($obj->request->name,$wPassword);
		/*删除cookie*/
		Typecho_Cookie::delete('__typecho_first_run');
		Typecho_Cookie::delete('__typecho_remember_name');
		Typecho_Cookie::delete('__typecho_remember_mail');

		//注册成功后，同步用户信息到vips表中
		if($obj->user->uid > 0){
			$invcode = $_COOKIE["TePassRefCookie"]==""?1:$_COOKIE["TePassRefCookie"];
			//随机生成邀请码
			static $source_string = 'E5FCDG3HQA4B1NOPIJ2RSTUV67MWX89KLYZ';
			$num = $obj->user->uid;
			$code = '';
			while ( $num > 0) {
				$mod = $num % 35;
				$num = ($num - $mod) / 35;
				$code = $source_string[$mod].$code;
			}
			if(empty($code[3])){
				$code = str_pad($code,4,'0',STR_PAD_LEFT);
			}
			$refcode = chr(rand(65,90)).$code;
			//获取默认的推广收益比例
			$db=Typecho_Db::get ();
			$refrate=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"ref_rate")->limit(1));
			if(!empty($refrate['cfg_value'])){
				$ref_rate = $refrate['cfg_value'];
			}else{
				$ref_rate = "0.00";
			}
			//在vips表中新建数据
			$sql = $db->insert('table.tepass_vips')->rows(array('vip_uid' => $obj->user->uid, 'vip_username' => $obj->user->name, 'vip_nickname' => $obj->user->screenName, 'vip_email' => $obj->user->mail, 'vip_endtime' => 0, 'vip_status' => 0, 'vip_invcode' => $invcode, 'vip_refcode' => $refcode,  'vip_ref_rate' => $ref_rate, 'vip_intime' => date('Y-m-d H:i:s',time())));
			$db->query($sql);	
		}		
		/*跳转地址(登录页面)*/		
		$obj->response->redirect($obj->request->referer);	

	}

	//登录后跳转  
	public static function forsigninend($obj) {
		$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";
		$callback_url = $protocol . $_SERVER['HTTP_HOST'] . "/tepass/refresh";

		//检查老会员是否在会员中心，没有就同步过来
		if($obj->user->uid > 0){
			$db=Typecho_Db::get ();
			$rsvips = $db->fetchRow($db->select()->from ('table.tepass_vips')->where ('vip_uid = ?', $obj->user->uid));
			if(empty($rsvips)){			
				$invcode = $_COOKIE["TePassRefCookie"]==""?1:$_COOKIE["TePassRefCookie"];
				//随机生成邀请码
				static $source_string = 'E5FCDG3HQA4B1NOPIJ2RSTUV67MWX89KLYZ';
				$num = $obj->user->uid;
				$code = '';
				while ( $num > 0) {
					$mod = $num % 35;
					$num = ($num - $mod) / 35;
					$code = $source_string[$mod].$code;
				}
				if(empty($code[3])){
					$code = str_pad($code,4,'0',STR_PAD_LEFT);
				}
				$refcode = chr(rand(65,90)).$code;
				//推广收益比例
				$refrate=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"ref_rate")->limit(1));
				if(!empty($refrate['cfg_value'])){
					$ref_rate = $refrate['cfg_value'];
				}else{
					$ref_rate = "0.00";
				}
				$sql = $db->insert('table.tepass_vips')->rows(array('vip_uid' => $obj->user->uid, 'vip_username' => $obj->user->name, 'vip_nickname' => $obj->user->screenName, 'vip_email' => $obj->user->mail, 'vip_endtime' => 0, 'vip_status' => 0, 'vip_invcode' => $invcode, 'vip_refcode' => $refcode,  'vip_ref_rate' => $ref_rate, 'vip_intime' => date('Y-m-d H:i:s',time())));
				$db->query($sql);
			}
		}
		if (NULL != $obj->request->referer) {
			$obj->response->redirect($obj->request->referer);
		}else{
			$obj->response->redirect($callback_url);
		}	
	}
	/**
	 * 把付费内容设置装入文章编辑页
	 *
	 * @access public
	 * @return void
	 */
	public static function setFeeContent($post) {
		$db = Typecho_Db::get();
		$row = $db->fetchRow($db->select('post_price,post_price_for_vip,post_price_for_eternal,post_see_type,post_content')->from('table.tepass_posts')->where('post_id = ?', $post->cid));
		$post_price = isset($row['post_price']) ? $row['post_price'] : '';
		$post_price_for_vip = isset($row['post_price_for_vip']) ? $row['post_price_for_vip'] : '';
		$post_price_for_eternal = isset($row['post_price_for_eternal']) ? $row['post_price_for_eternal'] : '';	
		$post_see_type = isset($row['post_see_type']) ? $row['post_see_type'] : '';	
		$post_content = isset($row['post_content']) ? $row['post_content'] : '';	
		//0、免费；1、VIP会员可见；2、单独付费可见；
		$html = '<section class="typecho-post-option">
					<label for="post_price" class="typecho-label" style="margin-bottom: 10px;color: red;">TePass文章付费设置</label>
					<select name="post_see_type" class="typecho-post-option">';
						if(empty($post_see_type)){
							$html .= '<option value="-1" selected="true">未进行付费设置</option><option value="0">0:限时免费</option>';
						}elseif($post_see_type == "0"){
							$html .= '<option value="0" selected="true">0:限时免费</option>';
						}else{							
							$html .= '<option value="0">0:限时免费</option>';
						}
						if($post_see_type == "1"){
							$html .= '<option value="1" selected="true">1:登录可见</option>';
						}else{
							$html .= '<option value="1">1:登录可见</option>';
						}
						if($post_see_type == "2"){	
							$html .= '<option value="2" selected="true">2:仅VIP会员可见</option>';
						}else{
							$html .= '<option value="2">2:仅VIP会员可见</option>';
						}
						if($post_see_type == "3"){	
							$html .= '<option value="3" selected="true">3:要单独付费</option>';
						}else{
							$html .= '<option value="3">3:要单独付费</option>';
						}
				$html .= '
					</select>
				</section>
				<section class="typecho-post-option">
					<label for="post_price" class="typecho-label">正常付费价格（元）</label>
					<p><input id="post_price" name="post_price" type="text" value="'.$post_price.'" class="w-100 text" placeholder="第3种方式必须设置价格"></p>
				</section>
				<section class="typecho-post-option">
					<label for="post_price_for_vip" class="typecho-label">VIP会员付费价格（元）</label>
					<p><input id="post_price_for_vip" name="post_price_for_vip" type="text" value="'.$post_price_for_vip.'" class="w-100 text" placeholder="不设置即免费"></p>
				</section>
				<section class="typecho-post-option">
					<label for="post_price_for_eternal" class="typecho-label">终身会员付费价格（元）</label>
					<p><input id="post_price_for_eternal" name="post_price_for_eternal" type="text" value="'.$post_price_for_eternal.'" class="w-100 text" placeholder="不设置即免费"></p>
				</section>
				<section class="typecho-post-option">
					<label for="post_content" class="typecho-label">付费可见内容</label>
					<p><textarea id="post_content" name="post_content" type="text" value="" style="width:100%;height:120px;" placeholder="支持HTML格式，与文中插入方式并存，二选一，建议放这里，更安全。">'.$post_content.'</textarea></p>
				</section>';
		_e($html);
	}


	/**
	 * 发布文章同时更新文章类型
	 *
	 * @access public
	 * @return void
	 */
	public static function updateFeeContent($contents, $post){
		$post_see_type = $post->request->get('post_see_type', 0);
		$post_price = $post->request->get('post_price', "0.00");
		$post_price_for_vip = $post->request->get('post_price_for_vip', "0.00");
		$post_price_for_eternal = $post->request->get('post_price_for_eternal', "0.00");
		$post_content = $post->request->get('post_content', NULL);
		$db = Typecho_Db::get();
		//查询付费表里是否有记录
		$queryfromtepasspost= $db->select()->from('table.tepass_posts')->where('post_id = ?', $post->cid); 
		$rowfromtepasspost = $db->fetchRow($queryfromtepasspost);
		if(empty($rowfromtepasspost)){
			//表里没有记录，再判断是否设置了付费
			if($post_see_type >= 0){
				$sql = $db->insert('table.tepass_posts')->rows(array('post_id' => $post->cid, 'post_uid' => $post->authorId, 'post_slug' => $post->slug, 'post_title' => $post->title, 'post_order_title' => $post->title, 'post_type' => $post->type, 'post_price' => $post_price, 'post_price_for_vip' => $post_price_for_vip, 'post_price_for_eternal' => $post_price_for_eternal, 'post_content' => $post_content, 'post_see_type' => $post_see_type, 'post_intime' => date('Y-m-d H:i:s',time())));
			}
		}else{
			$sql = $db->update('table.tepass_posts')->rows(array('post_slug' => $post->slug,'post_title' => $post->title,'post_type' => $post->type,'post_see_type' => $post_see_type,'post_price' => $post_price,'post_price_for_vip' => $post_price_for_vip,'post_price_for_eternal' => $post_price_for_eternal, 'post_content' => $post_content))->where('post_id = ?', $post->cid);
		}
		$db->query($sql);
	}
	
	/**
     * 后台编辑器添加VIP会员可见按钮
     * @access public
     * @return void
     */
	public static function forTePassToolbar(){
		?>
		<script> 
	      $(document).ready(function(){
	      	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-TePass-button" title="插入TePass付费可见代码块"><span style="background: none;font-size: 16px;border: 1px solid #dedede;padding: 2px;color: red;width: auto;height: auto;">TePass</span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-TePass-button').click(function(){
						var rs = "\r\n<!--TePass start-->\r\n\r\n<!--TePass end-->";
						var myField = $('#text')[0];
	            		insertAtCursor(myField,rs);
					})
				}

	        function insertAtCursor(myField, myValue) {
	            //IE 浏览器  
	            if (document.selection) {  
	                myField.focus();  
	                sel = document.selection.createRange();
	                sel.text = myValue;  
	                sel.select();  
	            }
	             //FireFox、Chrome等  
	            else if (myField.selectionStart || myField.selectionStart == '0') {  
	                var startPos = myField.selectionStart;  
	                var endPos = myField.selectionEnd; 
	                // 保存滚动条  
	                var restoreTop = myField.scrollTop;  
	                myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);  
	                if (restoreTop > 0) {myField.scrollTop = restoreTop;}  
	                myField.selectionStart = startPos + myValue.length;  
	                myField.selectionEnd = startPos + myValue.length;
	                myField.focus();  
	            } else {  
	                myField.value += myValue;
	                myField.focus();
	            }  
	        }
		  });
		</script>
		<?php
	}

	/**
     * 在主题post.php中直接调用
     *
     * @access public
     * @return int
     * @throws
     */
	public static function getReward(){
		$db = Typecho_Db::get();
        $cid = Typecho_Widget::widget('Widget_Archive')->cid;
		$query= $db->select()->from('table.tepass_posts')->where('post_id = ?', $cid ); 
		$rowPost = $db->fetchRow($query);
		if(empty($rowPost)){//没有付费记录才显示打赏
			//获取支付相关的配置参数
			$paySql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"pay");
			$paySqlRows = $db->fetchAll($paySql);
			$key = array_column($paySqlRows, 'cfg_key');
			$value = array_column($paySqlRows, 'cfg_value');
			$payRows = array_combine($key, $value);
			require_once("theme/ucenter/sign.php");
			$tepass_version = "0.7.4";
			
			//通过cookie查询是否打赏成功
			$queryReward = $db->select()->from('table.tepass_fees')->where('fee_cookie = ?', $_COOKIE["TePassBuyCookie"])->where('fee_status = ?', 1)->where('fee_cid = ?', $cid); 
			$rowReward = $db->fetchRow($queryReward);
			if(empty($rowReward)){//未打赏，没有付费记录
				require_once("theme/reward/need_your_reward.php");		
			}else{
				require_once("theme/reward/success_reward.php");	
			} 
		}
		//显示打赏记录
		$queryFees= $db->select()->from('table.tepass_fees')->join('table.users', 'table.users.uid = table.tepass_fees.fee_uid', Typecho_Db::LEFT_JOIN)->where('table.tepass_fees.fee_cid=?',$cid)->where('table.tepass_fees.fee_type = 3')->where('table.tepass_fees.fee_status = ?', 1)->order('table.tepass_fees.fee_id',Typecho_Db::SORT_DESC); 
		$rowFees = $db->fetchAll($queryFees);
		if(!empty($rowFees)){
			foreach($rowFees as $value){
				if($value['mail']){
					$smail=strtolower($value['mail']);
					$f=str_replace('@qq.com','',$smail);
					if(strstr($smail,"qq.com")&&is_numeric($f)&&strlen($f)<11&&strlen($f)>4){
						$navatar= '//q1.qlogo.cn/g?b=qq&nk='.$f.'&s=640';
					}else{
						$d=md5($smail);
						$navatar="https://cdn.v2ex.com/gravatar/".$d."?s=220&d=identicon";
					}
				}else{
					$navatar= '/usr/plugins/TePass/static/default_avatar.jpg';
				}
				$c_url=$c_url.' <img title="'.$value["fee_title"].' 打赏了'.$value["fee_total_price"].'元" src="' . $navatar . '">';
			}
			echo  '<div class="p-list"><div class="clusr pos"> ' . $c_url . ' </div></div>'; 
		}
	}
	/**
     * 在主题post.php中直接调用，如果post_content字段有内容的话
     *
     * @access public
     * @return int
     * @throws
     */
    public static function getTePass(){
		$db = Typecho_Db::get();
        $cid = Typecho_Widget::widget('Widget_Archive')->cid;
		$query= $db->select()->from('table.tepass_posts')->where('post_id = ?', $cid ); 
		$rowPost = $db->fetchRow($query);
		if(!empty($rowPost)){
			if($rowPost['post_content']){//有post_content才显示
				//获取支付相关的配置参数
				$paySql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"pay");
				$paySqlRows = $db->fetchAll($paySql);
				$key = array_column($paySqlRows, 'cfg_key');
				$value = array_column($paySqlRows, 'cfg_value');
				$payRows = array_combine($key, $value);
				require_once("theme/ucenter/sign.php");
				$tepass_version = "0.7.4";
				require_once("theme/post.php");
			}
		}
    }
	
	/**
     * 自动输出摘要
     * @access public
     * @return void
     */
    public static function excerptEx($html, $widget, $lastResult){
		$TePassRule='/<!--TePass start-->([\s\S]*?)<!--TePass end-->/i';
		preg_match_all($TePassRule, $html, $hide_words);
		if(!$hide_words[0]){
			$TePassRule='/&lt;!--TePass start--&gt;([\s\S]*?)&lt;!--TePass end--&gt;/i';
		}
		$html=trim($html);
		if (preg_match_all($TePassRule, $html, $hide_words)){
			$html = str_replace($hide_words[0], '', $html);
		}
		$html=Typecho_Common::subStr(strip_tags($html), 0, 140, "...");
		return $html;
	}
	
	/**
     * 自动输出内容
     * @access public
     * @return void
     */
    public static function contentEx($html, $widget, $lastResult){
		$TePassRule='/<!--TePass start-->([\s\S]*?)<!--TePass end-->/i';
		preg_match_all($TePassRule, $html, $hide_words);
		if(!$hide_words[0]){
			$TePassRule='/&lt;!--TePass start--&gt;([\s\S]*?)&lt;!--TePass end--&gt;/i';
		}
		$html = empty( $lastResult ) ? $html : $lastResult;
		$html = trim($html);
		if (preg_match_all($TePassRule, $html, $hide_content)){
			if(!empty($hide_content)){
				$db = Typecho_Db::get();
				
				//获取支付相关的配置参数
				$paySql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"pay");
				$paySqlRows = $db->fetchAll($paySql);
				$key = array_column($paySqlRows, 'cfg_key');
				$value = array_column($paySqlRows, 'cfg_value');
				$payRows = array_combine($key, $value);	
				require_once("theme/ucenter/sign.php");
				$tepass_version = "0.7.4";
				require_once("theme/html.php");
			}			
		}
		return $html;
	}
}
