<?php
echo '
<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v='.$tepass_version.'" type="text/css" />
<script src="/usr/plugins/TePass/static/js/tepass.js?v='.$tepass_version.'" async="async"></script>
<div class="tepasspost">
	<form id="tepassPost" onsubmit="return false" action="##" method="post">	
		<div class="feetype">';
		if($payRows['show_pay_type'] == "all"){ 
			echo '
			<label  for="feetype1" onmousedown="choose_pay(1)"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" nogallery="nogallery" no-zoom="true"><span>微信支付</span></label>
			<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">
			<label  for="feetype2" onmousedown="choose_pay(2)"><img id="labe2" src="/usr/plugins/TePass/static/alipay1.png" nogallery="nogallery" no-zoom="true"><span>支付宝支付</span></label>
			<input type="radio" id="feetype2" name="feetype" value="alipay">';
		}else{		
			if($payRows['show_pay_type'] == "alipay"){
				echo '
				<label  for="feetype2"><img id="labe2" src="/usr/plugins/TePass/static/alipay2.png" nogallery="nogallery" no-zoom="true"><span>支付宝支付</span></label>
				<input type="radio" id="feetype2" name="feetype" value="alipay" checked="checked">';
			}else{
				echo '
				<label  for="feetype1"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" nogallery="nogallery" no-zoom="true"><span>微信支付</span></label>
				<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">';
			}
		} 
		echo '</div><div class="cl"></div><span class="tepass_price">价格： '. $rowPost['post_price'] .' 元</span>';	
		if($rowPost['post_price_for_vip'] > 0){
			echo '<div class="cl"></div>	
			<span class="tepass_price_for_vip">VIP会员价格：'. $rowPost['post_price_for_vip'] .'元</span>';
		}else{
			echo '<div class="cl"></div>	
			<span class="tepass_price_for_vip">VIP会员免费</span>';
		}
		if($rowPost['post_price_for_eternal'] > 0){
			echo '<span class="tepass_price_for_eternal">终身会员价格：'. $rowPost['post_price_for_eternal'] .'元</span>
			<div class="cl"></div>';
		}else{
			echo '<span class="tepass_price_for_eternal">终身会员免费</span>
			<div class="cl"></div>';
		}		
		if($is_mobie){ 
			echo '<input type="hidden" id="userAgent" name="userAgent" value="isMobile" />';
		}else{ 
			echo '<input type="hidden" id="userAgent" name="userAgent" value="isDesktop" />';
		}	
			echo '
			<input id="verifybtn" onclick="tepassPost();" οnkeydοwn="enter_down(this.form, event);" type="button" value="付款"/>
			<input type="hidden" name="action" value="paypostsubmit" />
			<input type="hidden" id="callback_url" name="callback_url" value="'. $callback_url .'" />
			<input type="hidden" id="feecid" name="feecid" value="'. $rowPost['post_id'] .'" />
			<input type="hidden" id="feeuid" name="feeuid" value="'. Typecho_Cookie::get('__typecho_uid') .'" />
			<input type="hidden" id="tepass_time" name="tepass_time" value="'. $tepass_time .'" />
			<input type="hidden" id="tepass_sign" name="tepass_sign" value="'. $tepass_sign .'" />
		</form>
	<div class="cl"></div>';
	if(Typecho_Cookie::get('__typecho_uid') > 0){
		echo '<span class="tips">温馨提示：你已登录，付款后可永久阅读隐藏的内容。 </span>';
	}else{
		echo '<span class="tips">温馨提示：<a href="/tepass/signin">登录</a>付款后可永久阅读隐藏的内容。</span>';
	}
	echo '
	<span class="tepass_top_left">付费可读</span>
	<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png" nogallery="nogallery" no-zoom="true"></span>
	<div id="qrcode_box"></div><div id="bgdiv"></div>
</div>';
?>