<?php
echo '					
<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v='.$tepass_version.'" type="text/css" />				
<div class="tepasspost">
	<span class="tepass_content">'. $rowPost['post_content'].'</span>
	<span class="tepass_top_left">订单号：'. $rowFee["fee_id"].'</span>
	<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png" nogallery="nogallery" no-zoom="true"></span>
</div>';
?>