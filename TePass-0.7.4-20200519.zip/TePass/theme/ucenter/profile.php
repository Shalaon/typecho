<?php
include 'common.php';
include 'header.php';
include 'menu.php';

$stat = Typecho_Widget::widget('Widget_Stat');
?>
<style type="text/css">
.sns_icon {
    padding: 0 4px;
	width:32px;
}
.btn-red {
    border: none;
    background-color: #FF0500;
    cursor: pointer;
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    color: #FFF;
}
section {
	word-break: break-all;
}
</style>
<?php
//检测并更新用户会员状态，在三个地方都做了检测，refresh,my,buy
$user=Typecho_Widget::widget('Widget_User');
if($user->uid > 0){
	$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));
	$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"months_for_upgrade_eternal")->limit(1));
	//先检测一下用户是否存在，不存在就在会员中心增加
	if(empty($rsvips)){
		$invcode = $_COOKIE["TePassRefCookie"]==""?1:$_COOKIE["TePassRefCookie"];
		//随机生成邀请码
		static $source_string = 'E5FCDG3HQA4B1NOPIJ2RSTUV67MWX89KLYZ';
		$num = $user->uid;
		$code = '';
		while ( $num > 0) {
			$mod = $num % 35;
			$num = ($num - $mod) / 35;
			$code = $source_string[$mod].$code;
		}
		if(empty($code[3])){
			$code = str_pad($code,4,'0',STR_PAD_LEFT);
		}
		$refcode = chr(rand(65,90)).$code;
		$refrate=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"ref_rate")->limit(1));
		if(!empty($refrate['cfg_value'])){
			$ref_rate = $refrate['cfg_value'];
		}else{
			$ref_rate = "0.00";
		}
		$sql = $db->insert('table.tepass_vips')->rows(array('vip_uid' => $user->uid, 'vip_username' => $user->name, 'vip_nickname' => $user->screenName, 'vip_email' => $user->mail, 'vip_endtime' => 0, 'vip_status' => 0, 'vip_invcode' => $invcode, 'vip_refcode' => $refcode,  'vip_ref_rate' => $ref_rate, 'vip_intime' => date('Y-m-d H:i:s',time())));
		$db->query($sql);
	}
	
	//检查用户会员是否到期
	if($rsvips["vip_status"] < $rsconfig['cfg_value']){
		if(time() > $rsvips["vip_endtime"]){
			$updateVipstatus = $db->update('table.tepass_vips')->rows(array('vip_status'=>0))->where('vip_uid=?',$user->uid);
			$updateVipstatusRows= $db->query($updateVipstatus);	
		}		
	}

	//2.1更新用户的总支出vip_total_costs，单位为分
	$rstotal_cost=$db->fetchAll($db->select('fee_total_price')->from ('table.tepass_fees')->where('fee_uid=?',$user->uid)->where('fee_status=?',1)->where('fee_type < 3'));//充值或单独购买总支出
	$total_cost = 0;
	foreach($rstotal_cost as $key=>$val){
		$total_cost += $val['fee_total_price']*100;//单位为分
	}					
	$updateTotalCost = $db->update('table.tepass_vips')->rows(array('vip_total_costs'=>$total_cost))->where('vip_uid=?',$user->uid);
	$updateTotalCostRows= $db->query($updateTotalCost);	

	//2.2更新用户的推广总收益 vip_total_ref_income，单位为分
	$rstotal_income=$db->fetchAll($db->select('fee_total_price')->from ('table.tepass_fees')->join('table.tepass_vips', 'table.tepass_vips.vip_uid = table.tepass_fees.fee_uid', Typecho_Db::LEFT_JOIN)->where('vip_invcode=?',$rsvips["vip_refcode"])->where('fee_status=?',1));
	$total_income = 0;
	foreach($rstotal_income as $key=>$val){
		$total_income += $val['fee_total_price']*100;//单位为分
	}
	$total_ref_income = $total_income * $rsvips["vip_ref_rate"];//计算出总推广收益
	$total_money = (int)$rsvips["vip_points"] + (int)$total_ref_income;
	$updateTotalIncome = $db->update('table.tepass_vips')->rows(array('vip_total_income'=>(int)$total_income,'vip_total_ref_income'=>(int)$total_ref_income,'vip_money'=>(int)$total_money))->where('vip_uid=?',$user->uid);
	$updateTotalIncomeRows= $db->query($updateTotalIncome);		
	
	//如果是管理员，就计算一下卖会员的总金额
	if($user->pass('administrator', true)){		
		//2.1更新用户的总支出vip_total_costs，单位为分
		$rstotal_vip=$db->fetchAll($db->select('fee_total_price')->from ('table.tepass_fees')->where('fee_type=?',1)->where('fee_status=?',1));
		$total_vip = 0;
		foreach($rstotal_vip as $value){
			$total_vip += $value['fee_total_price']*100;//单位为分
		}
	}
}
?>
<div class="main">
    <div class="body container">
        <?php include 'page-title.php'; ?>
			<div class="row typecho-page-main">
				<div class="col-mb-12 col-tb-3">
					<p><a href="http://gravatar.com/emails/" title="<?php _e('在 Gravatar 上修改头像'); ?>"><?php echo '<img class="profile-avatar" src="/usr/plugins/TePass/static/default_avatar.jpg" alt="' . $user->screenName . '" />'; ?></a></p>
					<h3>绑定社交登录</h3>
					<p>
					<?php
						$snsSql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"sns");
						$snsSqlRows = $db->fetchAll($snsSql);

						$key = array_column($snsSqlRows, 'cfg_key');
						$value = array_column($snsSqlRows, 'cfg_value');

						$snsRows = array_combine($key, $value);
						
						if(!empty($snsRows['weibo_login'])){ 				
							$rssina=$db->fetchRow($db->select()->from ('table.tepass_sns')->where ('table.tepass_sns.uid=?  AND table.tepass_sns.platform = ?',$user->uid, 'sina')->limit(1));
							if(!empty($rssina)){
								echo '<a href="/tepass/wb_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_weibo.png" class="sns_icon"></a>';
							}else{
								echo '<a href="/tepass/wb_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_weibo_no.png" class="sns_icon"></a>';
							}
						}
						if(!empty($snsRows['qq_login'])){
							$rsqq=$db->fetchRow($db->select()->from ('table.tepass_sns')->where ('table.tepass_sns.uid=?  AND table.tepass_sns.platform = ?',$user->uid, 'qq')->limit(1));
							if(!empty($rsqq)){
							  echo '<a href="/tepass/qq_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_qq.png" class="sns_icon"></a>';
							}else{
							  echo '<a href="/tepass/qq_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_qq_no.png" class="sns_icon"></a>';	
							}
						}
						if(!empty($snsRows['github_login'])){
							$rsgithub=$db->fetchRow($db->select()->from ('table.tepass_sns')->where ('table.tepass_sns.uid=?  AND table.tepass_sns.platform = ?',$user->uid, 'github')->limit(1));
							if(!empty($rsgithub)){
							  echo '<a href="/tepass/gh_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_github.png" class="sns_icon"></a>';
							}else{
							  echo '<a href="/tepass/gh_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_github_no.png" class="sns_icon"></a>';	
							}
						} 
						if(!empty($snsRows['wechat_login'])){
							$rspayjs=$db->fetchRow($db->select()->from ('table.tepass_sns')->where ('table.tepass_sns.uid=?  AND table.tepass_sns.platform = ?',$user->uid, 'payjs')->limit(1));
							$uniqid = md5(uniqid(microtime(true),true));
							$uid_auth = $user->uid.'-'.$uniqid;
							if(!empty($rspayjs)){
							  echo '<a href="/tepass/wx_login?uid_auth='.$uid_auth.'" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_wechat.png" class="sns_icon"></a>';
							}else{
							  echo '<a href="/tepass/wx_login?uid_auth='.$uid_auth.'" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_wechat_no.png" class="sns_icon"></a>';			
							}
						} 
					?>
					</p>
				</div>

			<?php if($_GET['status'] == "buy"){ ?> 
				<div class="col-mb-12 col-tb-6 col-tb-offset-1 typecho-content-panel" role="form">
					<section>
						<h3><?php _e('基本信息'); ?></h3>
						<?php if($user->pass('administrator', true)){ ?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format(($rsvips['vip_money']+$total_vip)/100,2); ?></strong>元，其中卖会员收入<strong style="color:#ff5722;"><?php echo number_format($total_vip/100,2); ?></strong>元。<br/>
							身份类型：系统管理员<br/>
							到期时间：一生陪伴，永不过期！<br/>
							状态：正常
						<?php }else{ ?>
							<?php
							if($rsvips['vip_status'] >= $rsconfig['cfg_value']){
							?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format($rsvips['vip_money']/100,2); ?></strong>元，已提现<strong style="color:#ff5722;"><?php echo number_format($rsvips['fee_total_withdraw']/100,2); ?></strong>元<br/>
							会员类型：终身会员<br/>
							到期时间：一生陪伴，永不过期！<br/>
							状态：正常				
							<?php
							}elseif($rsvips['vip_status'] < $rsconfig['cfg_value'] && $rsvips['vip_status'] > 0){
							?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format($rsvips['vip_money']/100,2); ?></strong>元，已提现<strong style="color:#ff5722;"><?php echo number_format($rsvips['fee_total_withdraw']/100,2); ?></strong>元<br/>
							会员类型：VIP会员<br/>
							到期时间：<?php echo date('Y-m-d H:i:s',$rsvips['vip_endtime']); ?><br/>
							状态：正常
							<?php
							}else{
							?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format($rsvips['vip_money']/100,2); ?></strong>元，已提现<strong style="color:#ff5722;"><?php echo number_format($rsvips['fee_total_withdraw']/100,2); ?></strong>元<br/>
							会员类型：普通会员<br/>
							<a href="<?php echo $options->adminUrl?>extending.php?panel=TePass/theme/ucenter/profile.php&status=buy"><button class="btn btn-red">购买VIP会员</button></a><br/>
							状态：正常
							<?php
							}
							?>     
						<?php } ?>
					</section>
					
					<?php
					$paySql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"pay");
					$paySqlRows = $db->fetchAll($paySql);
					
					//key=>value关系的数组
					$key = array_column($paySqlRows, 'cfg_key');
					$value = array_column($paySqlRows, 'cfg_value');

					$payRows = array_combine($key, $value);

					$vipSql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"vip")->where('table.tepass_configs.cfg_value != ?',"");
					$vipSqlRows = $db->fetchAll($vipSql);
					require_once("sign.php");
					$tepass_version = "0.7.2";
					?>
					<script src="/usr/plugins/TePass/static/js/tepass.js?v=<?php echo $tepass_version; ?>" async="async"></script>
					<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v=<?php echo $tepass_version; ?>" type="text/css" />
					<div class="tepasspost">
						<form id="tepassVip" onsubmit="return false" action="##" method="post">		
							<div class="feetype">
							<?php if($payRows['show_pay_type']== "all"){ ?>
								<label  for="feetype1" onmousedown="choose_pay(1)"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" ><span>微信支付</span></label>
								<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">
								<label  for="feetype2" onmousedown="choose_pay(2)"><img id="labe2" src="/usr/plugins/TePass/static/alipay1.png" ><span>支付宝支付</span></label>
								<input type="radio" id="feetype2" name="feetype" value="alipay">
							<?php }else{
								if($payRows['show_pay_type'] == "alipay"){?>	
									<label  for="feetype2"><img id="labe2" src="/usr/plugins/TePass/static/alipay2.png" ><span>支付宝支付</span></label>
									<input type="radio" id="feetype2" name="feetype" value="alipay" checked="checked">
								<?php }else{?>
									<label  for="feetype1"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" ><span>微信支付</span></label>
									<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">
								<?php }
							}?>
							</div>
							<div style="clear:left;"></div>	
							<div  class="tepass_price">按每月31天，每年12个月算。</div>
							<select id="feeviptype" name="feeviptype" class="mdui-select" mdui-select>
								<?php
								 foreach($vipSqlRows as $value){
								?>
								<option value="<?php echo $value["cfg_key"]; ?>"><?php echo $value["cfg_name"].'：'.$value["cfg_value"].'元'; ?></option>
								<?php
								 }
								?>
							</select>
							<div class="cl"></div>
							<?php if ($is_mobie) { ?>
								<input type="hidden" id="userAgent" name="userAgent" value="isMobile" />
							<?php }else{ ?>
								<input type="hidden" id="userAgent" name="userAgent" value="isDesktop" />
							<?php } ?>	
							<input id="verifybtn" onclick="tepassVip();" οnkeydοwn="enter_down(this.form, event);" type="button" value="付款"/>
							<input type="hidden" name="action" value="payvipsubmit" />
							<input type="hidden" id="callback_url" name="callback_url" value="<?php $options->adminUrl(); ?>extending.php?panel=TePass/theme/ucenter/profile.php" />
							<input type="hidden" id="feeuid" name="feeuid" value="<?php echo $user->uid ?>" />
							<input type="hidden" id="tepass_time" name="tepass_time" value="<?php echo $tepass_time ?>" />
							<input type="hidden" id="tepass_sign" name="tepass_sign" value="<?php echo $tepass_sign ?>" />
						</form>
						<div class="cl"></div>
						<span class="tepass_top_left">购买VIP会员</span>
						<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png"></span>
						<div id="qrcode_box"></div><div id="bgdiv"></div>
					</div>
					<div style="clear: both"></div>				
				</div>		
			<?php }else{ ?>
				<div class="col-mb-12 col-tb-6 col-tb-offset-1 typecho-content-panel" role="form">
					<section>
						<h3><?php _e('基本信息'); ?></h3>
						<?php if($user->pass('administrator', true)){ ?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format(($rsvips['vip_money']+$total_vip)/100,2); ?></strong>元，其中卖会员收入<strong style="color:#ff5722;"><?php echo number_format($total_vip/100,2); ?></strong>元。<br/>
							身份类型：系统管理员<br/>
							到期时间：一生陪伴，永不过期！<br/>
							状态：正常
						<?php }else{ ?>
							<?php
							if($rsvips['vip_status'] >= $rsconfig['cfg_value']){
							?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format($rsvips['vip_money']/100,2); ?></strong>元，已提现<strong style="color:#ff5722;"><?php echo number_format($rsvips['fee_total_withdraw']/100,2); ?></strong>元<br/>
							会员类型：终身会员<br/>
							到期时间：一生陪伴，永不过期！<br/>
							状态：正常				
							<?php
							}elseif($rsvips['vip_status'] < $rsconfig['cfg_value'] && $rsvips['vip_status'] > 0){
							?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format($rsvips['vip_money']/100,2); ?></strong>元，已提现<strong style="color:#ff5722;"><?php echo number_format($rsvips['fee_total_withdraw']/100,2); ?></strong>元<br/>
							会员类型：VIP会员<br/>
							到期时间：<?php echo date('Y-m-d H:i:s',$rsvips['vip_endtime']); ?><br/>
							状态：正常
							<?php
							}else{
							?>
							帐号：<?php echo $rsvips['vip_username']; ?><br/>
							总资产：<strong style="color:#ff5722;"><?php echo number_format($rsvips['vip_money']/100,2); ?></strong>元，已提现<strong style="color:#ff5722;"><?php echo number_format($rsvips['fee_total_withdraw']/100,2); ?></strong>元<br/>
							会员类型：普通会员<br/>
							<a href="<?php echo $options->adminUrl?>extending.php?panel=TePass/theme/ucenter/profile.php&status=buy"><button class="btn btn-red">购买VIP会员</button></a><br/>
							状态：正常
							<?php
							}
							?>     
						<?php } ?>
					</section>

					<section>
						<h3><?php _e('投稿收益'); ?></h3>
						<?php if($user->pass('contributor', true)){ ?>
							<strong style="color:blue;display:block;">在本站发布付费资源，用户购买后，你将获得收益。</strong>
							到目前为止，你的投稿总收益 <?php echo number_format($rsvips['vip_points']/100,2); ?> 元。<br/>
							<?php if(empty($rsvips['vip_sckey'])){
								echo "在下方提交你的Server酱秘钥，有人购买了你投稿的作品，你会立即收到通知：";
							}else{
								echo "你的Server酱秘钥为：".$rsvips['vip_sckey'];
							}?>
							<br><a href="https://sc.ftqq.com/3.version">什么是Server酱？</a>
							<form action="" method="get" enctype="application/x-www-form-urlencoded" data-regestered="bind-sckey">
								<input type="hidden" name="panel" value="TePass/theme/ucenter/profile.php">
								<input id="vip_sckey" name="vip_sckey" class="mdui-textfield-input" type="text" placeholder="请输入Server酱秘钥..."/>
								<input type="submit" name="btn_submit" class="btn primary" value="提交">
							</form>
							<?php
								if(@$_GET["btn_submit"]){
									if(!empty($rsvips)){
										$updateSckey = $db->update('table.tepass_vips')->rows(array('vip_sckey'=>$_GET["vip_sckey"]))->where('vip_uid=?',$rsvips['vip_uid']);
										$updateSckeyRows= $db->query($updateSckey);		
									}
								}
							?>	
						<?php }else{ ?>
							<strong style="color:blue;display:block;">权限不足，无法投稿，可联系站长升级权限。</strong>
						<?php } ?>
					</section>

					<section>
						<h3><?php _e('推广收益'); ?></h3>
						<?php if(!empty($rsvips['vip_refcode'])){ ?>
						<strong style="color:blue;display:block;">邀请链接：<?php $options->siteUrl("/ref/".$rsvips['vip_refcode']);?></strong>
						<?php } ?>
						到目前为止，你共邀请到 <?php echo $rsvips['vip_refnum']; ?> 个注册用户。<br/>
						到目前为止，你的推广总收益 <?php echo number_format($rsvips['vip_total_ref_income']/100,2); ?> 元。<br/>
						被邀请者如果在本站付费购买资源，你将获得该用户总支出费用的<?php echo $rsvips['vip_ref_rate']*100;?>%作为奖励。<br/>
					</section>
					

					<?php
						$notice=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"for_my_center")->limit(1));
						if(!empty($notice['cfg_value'])){
					?>
						<section>
							<h3><?php _e('消息通知'); ?></h3>
							<?php echo $notice['cfg_value'];?>
						</section>
					<?php } ?>
					<br><br>
				</div>
			<?php } ?> 	
		</div>	
    </div>
</div>

<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
Typecho_Plugin::factory('admin/profile.php')->bottom();
include 'footer.php';
?>

<script language="javascript">
function externallinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i=0; i<anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href"))
		anchor.target = "_self";
	}
}
window.onload = externallinks;
</script>
