<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
include 'common.php';
Typecho_Widget::widget('Widget_User')->to($user);
if ($user->hasLogin()){
	header("Location: ".$this->options->adminUrl."extending.php?panel=TePass%2Ftheme%2Fucenter%2Fprofile.php"); 
}else{
	if(isset($_GET['redirect_url'])){
		$redirect_url = $_GET['redirect_url'];
	}else{
		//$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";
		//$callback_url = $protocol . $_SERVER['HTTP_HOST'] . "/tepass/refresh";
		//$redirect_url = $callback_url;
		$redirect_url = $this->options->adminUrl."extending.php?panel=TePass%2Ftheme%2Fucenter%2Fprofile.php";
	}
	$menu->title = _t('订单查询');
	$header = '<link rel="stylesheet" href="' . Typecho_Common::url('normalize.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
	<link rel="stylesheet" href="' . Typecho_Common::url('grid.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
	<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
	<!--[if lt IE 9]>
	<script src="' . Typecho_Common::url('html5shiv.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
	<script src="' . Typecho_Common::url('respond.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
	<![endif]-->';
?>
	<!DOCTYPE HTML>
	<html class="no-js">
		<head>
			<meta charset="<?php $options->charset(); ?>">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="renderer" content="webkit">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php _e('%s - %s', $menu->title, $options->title); ?></title>
			<meta name="robots" content="noindex, nofollow">
			<?php echo $header; ?>
		</head>
		<body<?php if (isset($bodyClass)) {echo ' class="' . $bodyClass . '"';} ?>>
		<!--[if lt IE 9]>
			<div class="message error browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
		<![endif]-->
		<link rel="stylesheet" href="/usr/plugins/TePass/static/css/front.css" type="text/css" />

	<div class="body container">
		<div class="typecho-logo">
			<h1><a href="<?php $this->options->siteUrl(); ?>"><?php $options->title(); ?></a></h1>
		</div>

		<div class="row typecho-page-main">
			<div class="col-mb-12 col-tb-6 col-tb-offset-3 typecho-content-panel">
				<div class="typecho-table-wrap">
					<div class="typecho-page-title">
						<nav class="navigation">
							<a href="#" class="active">订单查询</a>
						</nav>
					</div>
					<div class="signin-up">
						
						<?php	
						$db = Typecho_Db::get();
						if($user->hasLogin()){
							$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));
							if(!empty($rsvips)){
								if($rsvips['vip_status'] > 0){
									$rsvips['order_status'] = 2;
								}else{
									$rsvips['order_status'] = 1;
								}
							}else{
								$rsvips['order_status'] = 1;
							}
						}else{
							$rsvips['order_status'] = 0;
						}
						
						$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"search_order")->limit(1));
						if(empty($rsconfig)){
							$rsconfig['cfg_value'] = 0;
						}
						
						if($rsvips['order_status'] >= $rsconfig['cfg_value']){
						?>						
						
						<form action="" method="post" name="check_fee_id" rold="form">  
							<ul class="typecho-option">
								<li><input type="text" class="w-100" id="feeid" name="feeid" autocomplete="feeid" placeholder="请输入订单号..." required></li>
							</ul>
							<input type="button" name="btn_submit" class="btn primary" value="查询订单" onclick="javascript:checkfeeid(check_fee_id.feeid.value)">
						</form> 
						<div id="fee_box" style="max-width: 800px;margin: 0 auto;"></div>

						<script language="javascript">	
						function checkfeeid(fee_id){			
							var xmlObj; //定义XMLHttpRequest对象
							if(window.ActiveXObject){ //如果是浏览器支持ActiveXObjext则创建ActiveXObject对象
								xmlObj = new ActiveXObject("Microsoft.XMLHTTP");
							}else if(window.XMLHttpRequest){ //如果浏览器支持XMLHttpRequest对象则创建XMLHttpRequest对象
								xmlObj = new XMLHttpRequest();
							}
							xmlObj.onreadystatechange = callBackFun; //指定回调函数
							xmlObj.open('GET', '/usr/plugins/TePass/libs/checkorder.php?fee_id='+fee_id, true); //使用GET方法调用并传递参数的值
							xmlObj.send(null); //不发送任何数据，因为数据已经使用请求URL通过GET方法发送
							function callBackFun(){ //回调函数
								if(xmlObj.readyState == 4 && xmlObj.status == 200){ //如果服务器已经传回信息并没发生错误
									var data = JSON.parse(xmlObj.responseText);
									if(data.status=='yes'){ //如果服务器传回的内容为y，则表示存在
										if(data.fee_status=='1'){
													var box = document.getElementById("fee_box");
													box.innerHTML = '<div>此订单已成功付款！</br>订单号为：'+data.fee_id+'</br>订单标题：'+data.fee_title+'</br>隐藏内容：'+data.fee_content+'<\/div>';
										}else{
										  var box = document.getElementById("fee_box");
										  box.innerHTML = '<div>无效的订单<\/div>';
										}
									}else{
										var box = document.getElementById("fee_box");
										box.innerHTML = '<div>订单不存在<\/div>';
									}
								}
							}
						}
						</script>
						<?php
						}else{
						?>	
						<div>							
							<div style="text-align:center; max-width: 350px; margin: 10px auto;">
								权限不足，无法进行订单查询。
							</div>
						</div>
						<?php
						}
						?>
					</div>
					<div style="clear: both"></div>
				</div>
			</div>
		</div>
	</div>
	<?php
	include __ADMIN_DIR__ . '/common-js.php';
	?>
	<script>
	$(document).ready(function () {
		$('#feeid').focus();
	});
	</script>
	<script language="javascript">
	function externallinks() {
		if (!document.getElementsByTagName) return;
		var anchors = document.getElementsByTagName("a");
		for (var i=0; i<anchors.length; i++) {
			var anchor = anchors[i];
			if (anchor.getAttribute("href"))
			anchor.target = "_self";
		}
	}
	window.onload = externallinks;
	</script>
<?php } ?>