<?php
include 'header.php';
include 'menu.php';
?>
<style type="text/css">
.am-fr {
    float: right;
    margin-top: -10px;
}
li.am-pagination-prev {
    float: left;
    margin: 0 10px;
    list-style: none;
}
li.am-pagination-next {
    float: left;
    margin: 0 10px;
    list-style: none;
}
input[readonly]{
background-color: #b5b3b3;
}
textarea[readonly]{
background-color: #b5b3b3;
}
</style>
<?php
//检测并更新用户会员状态，在三个地方都做了检测，refresh,my,buy
$user=Typecho_Widget::widget('Widget_User');
if($user->uid > 0){
	$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));
	$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"months_for_upgrade_eternal")->limit(1));
	//先检测一下用户是否存在，不存在就在会员中心增加
	if(empty($rsvips)){
		$invcode = $_COOKIE["TePassRefCookie"]==""?1:$_COOKIE["TePassRefCookie"];
		//随机生成邀请码
		static $source_string = 'E5FCDG3HQA4B1NOPIJ2RSTUV67MWX89KLYZ';
		$num = $user->uid;
		$code = '';
		while ( $num > 0) {
			$mod = $num % 35;
			$num = ($num - $mod) / 35;
			$code = $source_string[$mod].$code;
		}
		if(empty($code[3])){
			$code = str_pad($code,4,'0',STR_PAD_LEFT);
		}
		$refcode = chr(rand(65,90)).$code;
		$refrate=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"ref_rate")->limit(1));
		if(!empty($refrate['cfg_value'])){
			$ref_rate = $refrate['cfg_value'];
		}else{
			$ref_rate = "0.00";
		}
		$sql = $db->insert('table.tepass_vips')->rows(array('vip_uid' => $user->uid, 'vip_username' => $user->name, 'vip_nickname' => $user->screenName, 'vip_email' => $user->mail, 'vip_endtime' => 0, 'vip_status' => 0, 'vip_invcode' => $invcode, 'vip_refcode' => $refcode,  'vip_ref_rate' => $ref_rate, 'vip_intime' => date('Y-m-d H:i:s',time())));
		$db->query($sql);
	}
	
	//检查用户会员是否到期
	if($rsvips["vip_status"] < $rsconfig['cfg_value']){
		if(time() > $rsvips["vip_endtime"]){
			$updateVipstatus = $db->update('table.tepass_vips')->rows(array('vip_status'=>0))->where('vip_uid=?',$user->uid);
			$updateVipstatusRows= $db->query($updateVipstatus);	
		}		
	}
}
?>
<div class="main">
    <div class="body container">
        <div class="typecho-page-title">
			<h2>购买VIP会员</h2>
		</div>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">            
                <div class="typecho-option-tabs fix-tabs clearfix">
                	<ul class="typecho-option-tabs">
						欢迎购买本站的VIP会员。
                    </ul>
                </div>
                <div class="col-mb-12 col-tb-12" role="main"> 
					<?php
					$paySql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"pay");
					$paySqlRows = $db->fetchAll($paySql);
					
					//key=>value关系的数组
					$key = array_column($paySqlRows, 'cfg_key');
					$value = array_column($paySqlRows, 'cfg_value');

					$payRows = array_combine($key, $value);

					$vipSql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"vip")->where('table.tepass_configs.cfg_value != ?',"");
					$vipSqlRows = $db->fetchAll($vipSql);
					require_once("sign.php");
					$tepass_version = "0.7.4";
					?>
					<script src="/usr/plugins/TePass/static/js/tepass.js?v=<?php echo $tepass_version; ?>" async="async"></script>
					<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v=<?php echo $tepass_version; ?>" type="text/css" />
					<div class="tepasspost">
						<form id="tepassVip" onsubmit="return false" action="##" method="post">		
							<div class="feetype">
							<?php if($payRows['show_pay_type']== "all"){ ?>
								<label  for="feetype1" onmousedown="choose_pay(1)"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" ><span>微信支付</span></label>
								<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">
								<label  for="feetype2" onmousedown="choose_pay(2)"><img id="labe2" src="/usr/plugins/TePass/static/alipay1.png" ><span>支付宝支付</span></label>
								<input type="radio" id="feetype2" name="feetype" value="alipay">
							<?php }else{
								if($payRows['show_pay_type'] == "alipay"){?>	
									<label  for="feetype2"><img id="labe2" src="/usr/plugins/TePass/static/alipay2.png" ><span>支付宝支付</span></label>
									<input type="radio" id="feetype2" name="feetype" value="alipay" checked="checked">
								<?php }else{?>
									<label  for="feetype1"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" ><span>微信支付</span></label>
									<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">
								<?php }
							}?>
							</div>
							<div style="clear:left;"></div>	
							<div  class="tepass_price">按每月31天，每年12个月算。</div>
							<select id="feeviptype" name="feeviptype" class="mdui-select" mdui-select>
								<?php
								 foreach($vipSqlRows as $value){
								?>
								<option value="<?php echo $value["cfg_key"]; ?>"><?php echo $value["cfg_name"].'：'.$value["cfg_value"].'元'; ?></option>
								<?php
								 }
								?>
							</select>
							<div class="cl"></div>
							<?php if ($is_mobie) { ?>
								<input type="hidden" id="userAgent" name="userAgent" value="isMobile" />
							<?php }else{ ?>
								<input type="hidden" id="userAgent" name="userAgent" value="isDesktop" />
							<?php } ?>	
							<input id="verifybtn" onclick="tepassVip();" οnkeydοwn="enter_down(this.form, event);" type="button" value="付款"/>
							<input type="hidden" name="action" value="payvipsubmit" />
							<input type="hidden" id="callback_url" name="callback_url" value="<?php $options->adminUrl(); ?>extending.php?panel=TePass/theme/ucenter/profile.php" />
							<input type="hidden" id="feeuid" name="feeuid" value="<?php echo $user->uid ?>" />
							<input type="hidden" id="tepass_time" name="tepass_time" value="<?php echo $tepass_time ?>" />
							<input type="hidden" id="tepass_sign" name="tepass_sign" value="<?php echo $tepass_sign ?>" />
						</form>
						<div class="cl"></div>
						<span class="tepass_top_left">购买VIP会员</span>
						<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png"></span>
						<div id="qrcode_box"></div><div id="bgdiv"></div>
					</div>
					<div style="clear: both"></div>				
				</div>
            </div><!-- end .typecho-list -->
        </div><!-- end .typecho-page-main -->
    </div>
</div>


<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
include 'footer.php';
?>

<script language="javascript">
function externallinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i=0; i<anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href"))
		anchor.target = "_self";
	}
}
window.onload = externallinks;
</script>
