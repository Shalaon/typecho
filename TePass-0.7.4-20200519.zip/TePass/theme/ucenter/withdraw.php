<?php
include 'header.php';
include 'menu.php';
$co = $request->get('co', '');
?>
<style type="text/css">
.am-fl {
    float: left;
    margin-top: -10px;
}
.am-fr {
	clear: both;
    float: right;
    margin-top: -10px;
}
li.am-pagination-prev {
    float: left;
    margin: 0 10px;
    list-style: none;
}
li.am-pagination-next {
    float: left;
    margin: 0 10px;
    list-style: none;
}
</style>
<?php 
	$db = Typecho_Db::get();
	$user=Typecho_Widget::widget('Widget_User');
	$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));	
	$queryFees= $db->select()->from('table.tepass_fees')->where('table.tepass_fees.fee_uid=?',$user->uid)->where('table.tepass_fees.fee_type = 9')->order('table.tepass_fees.fee_intime',Typecho_Db::SORT_DESC); 
	$rowFees = $db->fetchAll($queryFees);
?>
<div class="main">
    <div class="body container">
        <?php include 'page-title.php'; ?>        
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">            
                <div class="col-mb-12 col-tb-8" role="main"> 
                <form method="post" name="manage_posts" class="operate-form">
                <div class="typecho-table-wrap">
                    <table class="typecho-list-table">
                        <colgroup>
                            <col width="35%"/>
                            <col width="15%"/>
                            <col width="20%"/>
                            <col width="30%"/>
                        </colgroup>
                        <thead>
                            <tr>
                                <th><?php _e('单号'); ?></th>
                                <th style="text-align: center;"><?php _e('金额'); ?></th>
                                <th style="text-align: center;"><?php _e('状态'); ?></th>
                                <th style="text-align: center;"><?php _e('提交时间'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
							<?php
							  foreach($rowFees as $value){
							?>
							<tr>
								<td><?php echo $value["fee_id"]; ?></td>
								<td style="text-align: center;"><?php echo $value["fee_total_price"];?></td>
								<td style="text-align: center;">
								<?php if($value["fee_status"] == 1){
									echo "提现成功";
								}else{
									echo '在审核中';
								}?>
								</td>
								<td style="text-align: center;"><?php echo $value["fee_intime"];?></td>
							</tr>
							<?php
							  }
							?>
						</tbody>
                    </table>
                </div>
                </form><!-- end .operate-form -->
                <div class="typecho-list-operate clearfix">
                    <div class="am-cf">
					  <div class="am-fl">
					  共 <?=$totalrec;?> 条记录
					  </div>
					  <div class="am-fr">
						<ul class="am-pagination blog-pagination">
						  <?php if($page_now!=1){?>
							<li class="am-pagination-prev"><a href="<?=$url;?>?panel=TePass/theme/admin/posts.php&page_now=1" target="_self">首页</a></li>
						  <?php }?>
						  <?php if($page_now>1){?>
							<li class="am-pagination-prev"><a href="<?=$url;?>?panel=TePass/theme/admin/posts.php&page_now=<?=$before_page;?>" target="_self">&laquo; 上一页</a></li>
						  <?php }?>
						  <?php if($page_now<$page){?>
							<li class="am-pagination-next"><a href="<?=$url;?>?panel=TePass/theme/admin/posts.php&page_now=<?=$after_page;?>" target="_self">下一页 &raquo;</a></li>
						  <?php }?>
						  <?php if($page_now!=$page){?>
							<li class="am-pagination-next"><a href="<?=$url;?>?panel=TePass/theme/admin/posts.php&page_now=<?=$page;?>" target="_self">尾页</a></li>
						  <?php }?>
						</ul>
					  </div>
					</div>
                </div><!-- end .typecho-list-operate -->
				
				</div>
                <div class="col-mb-12 col-tb-4" role="form">
                    <?php
						//取uid的资料，更新vips表数据
						$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));	
						//获取最低提现额度		
						$reConfig=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"min_withdrawal")->limit(1));
						if(!empty($reConfig['cfg_value'])){
							$min_withdrawal = $reConfig['cfg_value'];
						}else{
							$min_withdrawal = "0.00";
						}
					?>
					
					<div style="text-align: left;">
						<strong style="color:blue;">邀请链接：<?php $options->siteUrl("/ref/".$rsvips['vip_refcode']); ?></strong><br/>
						1、发布收费资源，用户购买后将到达你的账户。<br/>
						2、邀请用户注册，你将获得该用户总支出费用的<?php echo $rsvips['vip_ref_rate']*100?>%作为奖励。<br/>
						<strong style="color:red;">为减少操作频率，提现最低额度 <?php echo $min_withdrawal;?> 元。</strong>
					</div>
					<div style="clear: both"></div>
					
					<div style="text-align: left;">
						累计总资产 <?php echo number_format($rsvips['vip_money']/100,2) ?>元， <br/>
						其中发布资源收益<?php echo number_format($rsvips['vip_points']/100,2) ?> 元， <br/>
						推广收益 <?php echo number_format($rsvips['vip_total_ref_income']/100,2) ?>元， <br/>
						到目前为止成功提现<?php echo number_format($rsvips['fee_total_withdraw']/100,2) ?>元。<br/><br/>
					</div>
					<div style="clear: both"></div>
					
                    <form action="" method="post" enctype="application/x-www-form-urlencoded" data-regestered="withdraw">
						<input type="hidden" name="panel" value="TePass/theme/ucenter/withdraw.php">
						<input id="fee_total_price" name="fee_total_price" class="mdui-textfield-input" type="text" placeholder="请输入提现金额..."/>
						<input type="submit" name="btn_submit" class="btn primary" value="申请提现">
					</form>
					
					<?php
						if(@$_POST["btn_submit"]){
							if(!empty($rsvips)){
								if($_POST["fee_total_price"] >= $min_withdrawal){ 
									//先算算还剩下多少钱
									$left_total_money = $rsvips['vip_money'] - $rsvips['fee_total_withdraw'];
									if($left_total_money >= $_POST["fee_total_price"]*100){
										//有提交未审核的不能重复提交
										$queryFees= $db->select()->from('table.tepass_fees')->where('table.tepass_fees.fee_uid=?',$user->uid)->where('table.tepass_fees.fee_type = 9')->where('table.tepass_fees.fee_status = 0')->order('table.tepass_fees.fee_intime',Typecho_Db::SORT_DESC)->limit(1); 
										$rowFees = $db->fetchRow($queryFees);
										if(empty($rowFees)){
											//提交到消费记录
											$fee_id = rand(9000, 9999) . date("YmdHis",time());//提现订单号18位
											$feessql = $db->insert('table.tepass_fees')->rows(array('fee_id' => $fee_id, 'fee_uid' => $user->uid, 'fee_cid' => 0, 'fee_type' => 9, 'fee_title' => "申请收益提现", 'fee_total_price' => $_POST["fee_total_price"], 'fee_check' => "pending",  'fee_total_days' => 0, 'fee_pay_type' => "withdraw", 'fee_status' => 0, 'fee_intime' => date('Y-m-d H:i:s',time())));
											$feessqlRows= $db->query($feessql);	
											echo "<script>alert('提现申请已提交，请等待审核！')</script>";
										}else{
											echo "<script>alert('已提交申请，不可重复提交！')</script>";
										}
									}else{
										echo "<script>alert('金额不足，请重新填写金额！')</script>";
									}
								}else{
									echo "<script>alert('提现金额不符合最低要求，请重新填写金额！')</script>";
								}
							}else{
								header("Location: /tepass/signin"); 
							}
						}
					?>	
					
                </div>
            </div><!-- end .typecho-list -->
        </div><!-- end .typecho-page-main -->
    </div>
</div>

<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
include 'footer.php';
?>

<script language="javascript">
function externallinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i=0; i<anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href"))
		anchor.target = "_self";
	}
}
window.onload = externallinks;
</script>
