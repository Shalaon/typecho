<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
include 'common.php';
$menu->title = _t('微信登录');
$header = '<link rel="stylesheet" href="' . Typecho_Common::url('normalize.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('grid.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
<!--[if lt IE 9]>
<script src="' . Typecho_Common::url('html5shiv.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
<script src="' . Typecho_Common::url('respond.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
<![endif]-->';

?>
<!DOCTYPE HTML>
<html class="no-js">
	<head>
		<meta charset="<?php $options->charset(); ?>">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php _e('%s - %s', $menu->title, $options->title); ?></title>
		<meta name="robots" content="noindex, nofollow">
		<?php echo $header; ?>
	</head>
	<body<?php if (isset($bodyClass)) {echo ' class="' . $bodyClass . '"';} ?>>
	<!--[if lt IE 9]>
		<div class="message error browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
	<![endif]-->
	<link rel="stylesheet" href="/usr/plugins/TePass/static/css/front.css" type="text/css" />

<div class="body container">
	<div class="typecho-logo">
		<h1><a href="<?php $this->options->siteUrl(); ?>"><?php $options->title(); ?></a></h1>
	</div>

	<div class="row typecho-page-main">
		<div class="col-mb-12 col-tb-6 col-tb-offset-3 typecho-content-panel">
			<div class="typecho-table-wrap">
				<div style="text-align: center;">				
				<?php
				$db = Typecho_Db::get(); 			
				$payjs = $db->fetchRow($db->select()->from('table.tepass_configs')->where('cfg_key = ?', "wechat_login")->limit(1));
				$payjs_mid = $payjs['cfg_value'];
				if(!empty($_GET['openid'])){
					//查询openid是否绑定过
					$openid = $_GET['openid'];
					$installed = $db->fetchRow($db->select()->from('table.tepass_sns')->where('openid = ?', $openid)->limit(1));	
					if (!empty($installed)) {
						if (!empty($_GET['authCode'])) {
							$authCode = $_GET['authCode'];
						}else{
							$uid_auth = explode("-",$_GET['uid_auth']);
							$uid = $uid_auth[0];
							$authCode = $uid_auth[1];
						}
						$db->query($db->update('table.tepass_sns')->rows(array('authCode' => $authCode, 'refresh_token' => date('Y-m-d H:i:s',time())))->where('openid = ?',$openid));							
						//手机端提示登录成功	
						header("Location: /tepass/wx_login_end?uid=".$installed['uid']); 						
					}else{
						if(!empty($_GET['uid_auth'])){
							$uid_auth = explode("-",$_GET['uid_auth']);
							$uid = $uid_auth[0];
							$authCode = $uid_auth[1];
							if($uid > 0){
								$expire_time = 3600 * 24;
								$rows = array(
									'openid' => $openid,
									'uid' => $uid,
									'platform' => "payjs",
									'bind_time' => time(),
									'expires_in' => $expire_time,
									'authCode' => $authCode,
									'refresh_token' => date('Y-m-d H:i:s',time())
								);
								$db->query($db->insert('table.tepass_sns')->rows($rows));
								//手机端提示登录成功
								header("Location: /tepass/wx_login_end?uid=".$installed['uid']);
							}else{								
								//没有绑定微信登录需先登录账号
								header("Location: /tepass/notice?tip=need_account_login");
							}
						}else{		
							//啥都没有，手机端提示绑定需先登录
							header("Location: /tepass/notice?tip=need_account_login");
						}
					}	
				}else{					
					$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";
					$siteUrl = $protocol . $_SERVER['HTTP_HOST'];
					if(!empty($_GET['uid_auth'])){
						$uid_auth = $_GET['uid_auth'];
						$auth = explode("-",$_GET['uid_auth']);
						$uid = $auth[0];
						$authCode = $auth[1];
						echo '
						<img src="https://www.kuaizhan.com/common/encode-png?large=true&data='.$siteUrl.'/tepass/wx_login?uid_auth='.$uid_auth.'"><br/>
						<input id="authCode" type="hidden" value="'.$authCode.'">
						<a href="https://payjs.cn/api/openid?mchid='.$payjs_mid.'&callback_url='.$siteUrl.'/tepass/wx_login?uid_auth='.$uid_auth.'">
							<button type="submit" class="btn primary" style="max-width: 150px;">微信登录</button>
						</a>';
					}else{
						if(empty($_GET['authCode'])){
							$uniqid = md5(uniqid(microtime(true),true));
							echo '
							<img src="https://www.kuaizhan.com/common/encode-png?large=true&data='.$siteUrl.'/tepass/wx_login?authCode='.$uniqid.'"><br/>
							<input id="authCode" type="hidden" value="'.$uniqid.'">
							<a href="https://payjs.cn/api/openid?mchid='.$payjs_mid.'&callback_url='.$siteUrl.'/tepass/wx_login?authCode='.$uniqid.'">
								<button type="submit" class="btn primary" style="max-width: 150px;">微信登录</button>
							</a>';
						}else{
							$uniqid = $_GET['authCode'];
							echo '
							<img src="https://www.kuaizhan.com/common/encode-png?large=true&data='.$siteUrl.'/tepass/wx_login?authCode='.$uniqid.'"><br/>
							<input id="authCode" type="hidden" value="'.$uniqid.'">
							<a href="https://payjs.cn/api/openid?mchid='.$payjs_mid.'&callback_url='.$siteUrl.'/tepass/wx_login?authCode='.$uniqid.'">
								<button type="submit" class="btn primary" style="max-width: 150px;">微信登录</button>
							</a>';
						}
					}
				} ?>				
				<script language="javascript">
				function payjs_login_status(){	
					var authCode = document.getElementById("authCode").value;
				   $.ajax({  
					url:'/usr/plugins/TePass/libs/wechat.php',
					dataType:'json', 
					type:'post',  
					data:{"authCode":authCode}, 
					success:function(data){
					  if(data.auth_status == '1'){
						window.clearInterval(int);
						window.location.href = "/tepass/wx_login_end?uid="+data.auth_uid;	
					  }else if(data.auth_status =='2'){
						window.clearInterval(int);
						window.location.href = "/tepass/notice?tip=wechat_bind_fail";
					  }			 
					},  
				 });
				}
				
				var repeat = 120;
				var int=self.setInterval(function(){
					if (repeat == 0) {
						window.clearInterval(int);
						window.location.href = "/tepass/notice?tip=wechat_qrcode_expire";
					} else {
						repeat--;
						payjs_login_status();
					}
				},1000);
				</script>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include __ADMIN_DIR__ . '/common-js.php';
?>

<script language="javascript">
function externallinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i=0; i<anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href"))
		anchor.target = "_self";
	}
}
window.onload = externallinks;
</script>