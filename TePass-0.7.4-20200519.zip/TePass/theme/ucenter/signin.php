<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
include 'common.php';
Typecho_Widget::widget('Widget_User')->to($user);
if ($user->hasLogin()){
	header("Location: /tepass/refresh"); 
}else{
	if(isset($_GET['redirect_url'])){
		$redirect_url = $_GET['redirect_url'];
	}else{
		$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";
		$callback_url = $protocol . $_SERVER['HTTP_HOST'] . "/tepass/refresh";
		$redirect_url = $callback_url;
		//$redirect_url = $this->options->adminUrl."extending.php?panel=TePass/theme/ucenter/profile.php";
	}
	$menu->title = _t('登录');
	$header = '<link rel="stylesheet" href="' . Typecho_Common::url('normalize.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
	<link rel="stylesheet" href="' . Typecho_Common::url('grid.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
	<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
	<!--[if lt IE 9]>
	<script src="' . Typecho_Common::url('html5shiv.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
	<script src="' . Typecho_Common::url('respond.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
	<![endif]-->';
?>
	<!DOCTYPE HTML>
	<html class="no-js">
		<head>
			<meta charset="<?php $options->charset(); ?>">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="renderer" content="webkit">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php _e('%s - %s', $menu->title, $options->title); ?></title>
			<meta name="robots" content="noindex, nofollow">
			<?php echo $header; ?>
		</head>
		<body<?php if (isset($bodyClass)) {echo ' class="' . $bodyClass . '"';} ?>>
		<!--[if lt IE 9]>
			<div class="message error browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
		<![endif]-->
		<link rel="stylesheet" href="/usr/plugins/TePass/static/css/front.css" type="text/css" />

	<div class="body container">
		<div class="typecho-logo">
			<h1><a href="<?php $this->options->siteUrl(); ?>"><?php $options->title(); ?></a></h1>
		</div>

		<div class="row typecho-page-main">
			<div class="col-mb-12 col-tb-6 col-tb-offset-3 typecho-content-panel">
				<div class="typecho-table-wrap">
					<div class="typecho-page-title">
						<nav class="navigation">
							<a href="/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>tepass/signin" class="active">登录</a>
							<a href="/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>tepass/forgot">找回密码</a>
							<?php if($this->options->allowRegister): ?>
								<a href="/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>tepass/signup">注册</a>
							<?php endif; ?>
						</nav>
					</div>
					<div class="signin-up">
						<form action="<?php $this->options->loginAction()?>" method="post" name="login" rold="form">				                                  
							<input type="hidden" name="referer" value="<?php echo $redirect_url; ?>" />
							<ul class="typecho-option">
								<li><input type="text" class="w-100" id="name" name="name" autocomplete="username" placeholder="请输入用户名" required></li>
							</ul>
							<ul class="typecho-option">
								<li><input type="password" class="w-100" id="password" name="password" autocomplete="current-password" placeholder="请输入密码" required></li>
							</ul>
							<button type="submit" class="btn primary">登录</button>
						</form> 
						<div class="social_login_oauth">
							其它方式登录<br/>
							<?php
								//获取支付相关的配置参数
								$db = Typecho_Db::get();
								$snsSql = $db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_type=?',"sns");
								$snsSqlRows = $db->fetchAll($snsSql);

								$key = array_column($snsSqlRows, 'cfg_key');
								$value = array_column($snsSqlRows, 'cfg_value');

								$snsRows = array_combine($key, $value);
								if(!empty($snsRows['weibo_login'])){
									echo '<a href="/tepass/wb_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_weibo.png"></a>';
								}
								if(!empty($snsRows['qq_login'])){
									echo '<a href="/tepass/qq_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_qq.png"></a>';
								}
								if(!empty($snsRows['github_login'])){
									echo '<a href="/tepass/gh_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_github.png"></a>';
								}
								if(!empty($snsRows['wechat_login'])){
									echo '<a href="/tepass/wx_login" rel="nofollow"><img src="/usr/plugins/TePass/static/sns/icon_wechat.png"></a>';
								}
							?>
						</div>
					</div>
					<div style="clear: both"></div>
				</div>
			</div>
		</div>
	</div>
	<?php
	include __ADMIN_DIR__ . '/common-js.php';
	?>
	<script>
	$(document).ready(function () {
		$('#name').focus();
	});
	</script>
	<script language="javascript">
	function externallinks() {
		if (!document.getElementsByTagName) return;
		var anchors = document.getElementsByTagName("a");
		for (var i=0; i<anchors.length; i++) {
			var anchor = anchors[i];
			if (anchor.getAttribute("href"))
			anchor.target = "_self";
		}
	}
	window.onload = externallinks;
	</script>
<?php } ?>