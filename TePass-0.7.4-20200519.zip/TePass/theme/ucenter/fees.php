<?php
include 'header.php';
include 'menu.php';
?>
<style type="text/css">
.am-fr {
    float: right;
    margin-top: -10px;
}
li.am-pagination-prev {
    float: left;
    margin: 0 10px;
    list-style: none;
}
li.am-pagination-next {
    float: left;
    margin: 0 10px;
    list-style: none;
}
input[readonly]{
background-color: #b5b3b3;
}
textarea[readonly]{
background-color: #b5b3b3;
}
</style>
<?php
$user=Typecho_Widget::widget('Widget_User');
if($user->uid > 0){
	$db = Typecho_Db::get();
	$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));
	$queryPosts= $db->select()->from('table.tepass_fees')->where('table.tepass_fees.fee_type < 9')->where('table.tepass_fees.fee_status = 1')->where('table.tepass_fees.fee_uid = ?',$user->uid); 
	$page_now = isset($_GET['page_now']) ? intval($_GET['page_now']) : 1;
	if($page_now<1){
		$page_now=1;
	}
	$resultTotal = $db->fetchAll($queryPosts);
	$page_rec=10;
	$totalrec=count($resultTotal);
	$page=ceil($totalrec/$page_rec);
	if($page_now>$page){
		$page_now=$page;
	}
	if($page_now<=1){
		$before_page=1;
		if($page>1){
			$after_page=$page_now+1;
		}else{
			$after_page=1;
		}
	}else{
		$before_page=$page_now-1;
		if($page_now<$page){
			$after_page=$page_now+1;
		}else{
			$after_page=$page;
		}
	}
	$i=($page_now-1)*$page_rec<0?0:($page_now-1)*$page_rec;
	$queryGoods= $db->select()->from('table.tepass_fees')->join('table.users', 'table.users.uid = table.tepass_fees.fee_uid', Typecho_Db::LEFT_JOIN)->where('table.tepass_fees.fee_type < 9')->where('table.tepass_fees.fee_status = 1')->where('table.tepass_fees.fee_uid = ?',$user->uid)->order('table.tepass_fees.fee_id',Typecho_Db::SORT_DESC)->offset($i)->limit($page_rec); 
	$rowGoods = $db->fetchAll($queryGoods);
}
?>
<div class="main">
    <div class="body container">
        <div class="typecho-page-title">
			<h2>消费记录<a href="<?php $options->adminUrl(); ?>extending.php?panel=TePass/theme/ucenter/fees.php&status=search">查询订单</a></h2>
		</div>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">            
                <div class="typecho-option-tabs fix-tabs clearfix">
                	<ul class="typecho-option-tabs">
					<?php if($_GET['status'] == "search"){ ?> 
						输入订单号，可查询到该订单隐藏的内容。
					<?php }else{ ?>
						你在本站的UID为：<?php echo $user->uid; ?>，若你之前是未登录购买的，订单号不会在下面列表中，请联系管理员给你绑定订单。
					<?php } ?>
                    </ul>
                </div>
                <div class="col-mb-12 col-tb-12" role="main">    
             	<?php if($_GET['status'] == "search"){ ?>                
					<div style="text-align:center; max-width: 350px; margin: 10px auto;">
						<form action="" method="post" class="new-order-unit" data-regestered="regestered" name="check_fee_id">
							<input id="feeid" name="feeid" class="mdui-textfield-input" type="text" placeholder="请输入订单号..."/>
							<input type="button" name="btn_submit" class="btn primary" value="查询订单" onclick="javascript:checkfeeid(check_fee_id.feeid.value)">
						</form>
					</div>
					<?php if($_GET['fee_id']){
						$rsorder=$db->fetchRow($db->select()->from ('table.tepass_fees')->where('fee_id = ?',$_GET["fee_id"])->limit(1));
					?>
					<div id="fee_box" style="max-width: 500px;margin: 0 auto;">
						<div>
							<?php if($rsorder["fee_status"] == "1"){
								echo '<span style="color:blue;">此订单已成功付款！</span>';
							}elseif($rsorder["fee_status"] == "2"){
								echo '<span style="color:red;">此订单付款失败！</span>';
							}else{
								echo '<span style="color:black;">此订单未付款！</span>';
							}?>
							
							<a href="<?php echo $request->makeUriByRequest('fee_id='.$rsorder["fee_id"]); ?>">修改付款信息</a></br>订单号为：<?php echo $rsorder["fee_id"]; ?></br>
							订单标题：<?php echo $rsorder["fee_title"]; ?></br>
							用户UID：<?php echo $rsorder["fee_uid"]; ?>
						</div>
					</div>  
					<?php }else{ ?>
					<div id="fee_box" style="max-width: 500px;margin: 0 auto;"></div>  
					<script language="javascript">	
						function checkfeeid(fee_id){			
							var xmlObj; //定义XMLHttpRequest对象
							if(window.ActiveXObject){ //如果是浏览器支持ActiveXObjext则创建ActiveXObject对象
								xmlObj = new ActiveXObject("Microsoft.XMLHTTP");
							}else if(window.XMLHttpRequest){ //如果浏览器支持XMLHttpRequest对象则创建XMLHttpRequest对象
								xmlObj = new XMLHttpRequest();
							}
							xmlObj.onreadystatechange = callBackFun; //指定回调函数
							xmlObj.open('GET', '/usr/plugins/TePass/libs/checkorder.php?fee_id='+fee_id, true); //使用GET方法调用并传递参数的值
							xmlObj.send(null); //不发送任何数据，因为数据已经使用请求URL通过GET方法发送
							function callBackFun(){ //回调函数
								if(xmlObj.readyState == 4 && xmlObj.status == 200){ //如果服务器已经传回信息并没发生错误
									var data = JSON.parse(xmlObj.responseText);
									if(data.status=='yes'){ //如果服务器传回的内容为y，则表示存在
										var box = document.getElementById("fee_box");
										box.innerHTML = '<div>'+data.fee_status_desc+'<a href="<?php echo $request->makeUriByRequest('fee_id='); ?>'+data.fee_id+'">修改付款信息<\/a></br>订单号为：'+data.fee_id+'</br>订单标题：'+data.fee_title+'</br>隐藏内容：'+data.fee_content+'<\/div>';
									}else{
										var box = document.getElementById("fee_box");
										box.innerHTML = '<div>无效的订单或订单不存在<\/div>';
									}
								}
							}
						}
					</script>   
					<?php } ?>
                <?php }else{ ?>
					<form method="post" name="manage_posts" class="operate-form">
					<div class="typecho-table-wrap">
						<table class="typecho-list-table">
							<colgroup>
								<col width="20%"/>
								<col width="30%"/>
								<col width="10%"/>
								<col width="10%"/>
								<col width="10%"/>
								<col width="20%"/>
							</colgroup>
							<thead>
								<tr>
									<th><?php _e('订单号'); ?></th>
									<th><?php _e('标题'); ?></th>
									<th><?php _e('价格'); ?></th>
									<th><?php _e('方式'); ?></th>
									<th><?php _e('状态'); ?></th>
									<th><?php _e('时间'); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php
								  foreach($rowGoods as $value){
								?>
								<tr id="<?=$value["fee_id"];?>">
									<td><?php echo $value["fee_id"]; ?></td>	
									<td><a href="<?php $options->siteUrl("/ref/".$rsvips['vip_refcode']);?>?cid=<?php echo $value["fee_cid"]; ?>"><?php echo $value["fee_title"]; ?></a></td>									
									<td><?php echo $value["fee_total_price"]; ?></td>
									<td><?php echo $value["fee_pay_type"]; ?></td>		
									<td><?php if($value["fee_status"] == 0){
										echo "未付";
									}elseif($value["fee_status"] == 1){
										echo '<span style="color:blue;">成功</span>';
									}else{
										echo '<span style="color:red;">失败</span>';
									}
									?></td>
									<td><?php echo $value["fee_intime"]; ?></td>
								</tr>
								<?php
								  }
								?>
							</tbody>
						</table>
					</div>
					</form><!-- end .operate-form -->

					<div class="typecho-list-operate clearfix">
						<div class="am-cf">
						  共 <?=$totalrec;?> 条记录
						  <div class="am-fr">
							<ul class="am-pagination blog-pagination">
							  <?php if($page_now!=1){?>
								<li class="am-pagination-prev"><a href="<?=$url;?>?panel=TePass/theme/ucenter/fees.php&page_now=1" target="_self">首页</a></li>
							  <?php }?>
							  <?php if($page_now>1){?>
								<li class="am-pagination-prev"><a href="<?=$url;?>?panel=TePass/theme/ucenter/fees.php&page_now=<?=$before_page;?>" target="_self">&laquo; 上一页</a></li>
							  <?php }?>
							  <?php if($page_now<$page){?>
								<li class="am-pagination-next"><a href="<?=$url;?>?panel=TePass/theme/ucenter/fees.php&page_now=<?=$after_page;?>" target="_self">下一页 &raquo;</a></li>
							  <?php }?>
							  <?php if($page_now!=$page){?>
								<li class="am-pagination-next"><a href="<?=$url;?>?panel=TePass/theme/ucenter/fees.php&page_now=<?=$page;?>" target="_self">尾页</a></li>
							  <?php }?>
							</ul>
						  </div>
						</div>
					</div><!-- end .typecho-list-operate -->
				
                <?php } ?>               
				</div>
            </div><!-- end .typecho-list -->
        </div><!-- end .typecho-page-main -->
    </div>
</div>


<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
include 'footer.php';
?>

<script language="javascript">
function externallinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i=0; i<anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href"))
		anchor.target = "_self";
	}
}
window.onload = externallinks;
</script>
