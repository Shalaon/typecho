<?php
//产生付款界面验签等相关数据
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://": "http://";
$callback_url = $protocol . $_SERVER['HTTP_HOST'] . "/tepass/notice?tip=pay_post_success" . $_SERVER['REQUEST_URI'];
if(!empty($payRows['alipay_app_private_key'])){
	$tepass_secret = $payRows['alipay_app_private_key'];
}else{
	$tepass_secret = $payRows['payjs_wxpay_mchkey']."Payjs.Cn";
}
$tepass_key = strtoupper(md5(base64_encode("PangSuan.Com@2020#0402"))).base64_encode("TePass".$tepass_secret);
$tepass_time = crypt(time(), '15');
$tepass_sign = strtoupper(md5($tepass_key.$tepass_time));

//判断浏览器类型
$user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
$is_ipad = (strpos($user_agent, 'ipad')) ? true : false;
if(!$is_ipad){		
	if($user_agent){
		$is_mobie = preg_match('/(Mobile|iPod|iPhone|Android|Opera Mini|BlackBerry|webOS|UCWEB|Blazer|PSP)/i', $user_agent);
	}
}

//生成TePassBuyCookie
$cookietime=$payRows['cookie_time']==""?1:$payRows['cookie_time'];
if(!isset($_COOKIE["TePassBuyCookie"])){
	$str_md1 = substr(md5(uniqid(microtime(true),true)),0,10);
	$str_md2 = substr(md5("Pangsuan.Com".time()),0,22);
	
	$randomCode = strtoupper($str_md1.$str_md2);
	setcookie("TePassBuyCookie",$randomCode,time()+3600*24*$cookietime,'/');
}
