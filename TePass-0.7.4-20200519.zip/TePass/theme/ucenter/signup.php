<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
include 'common.php';
$menu->title = _t('注册');
$header = '<link rel="stylesheet" href="' . Typecho_Common::url('normalize.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('grid.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('css')) . '">
<!--[if lt IE 9]>
<script src="' . Typecho_Common::url('html5shiv.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
<script src="' . Typecho_Common::url('respond.js?v=' . $suffixVersion, $options->adminStaticUrl('js')) . '"></script>
<![endif]-->';
?>
<!DOCTYPE HTML>
<html class="no-js">
    <head>
        <meta charset="<?php $options->charset(); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="renderer" content="webkit">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php _e('%s - %s', $menu->title, $options->title); ?></title>
        <meta name="robots" content="noindex, nofollow">
        <?php echo $header; ?>
    </head>
    <body<?php if (isset($bodyClass)) {echo ' class="' . $bodyClass . '"';} ?>>
    <!--[if lt IE 9]>
        <div class="message error browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
    <![endif]-->
	<link rel="stylesheet" href="/usr/plugins/TePass/static/css/front.css" type="text/css" />

<div class="body container">
    <div class="typecho-logo">
        <h1><a href="<?php $options->siteUrl(); ?>"><?php $options->title(); ?></a></h1>
    </div>

    <div class="row typecho-page-main">
        <div class="col-mb-12 col-tb-6 col-tb-offset-3 typecho-content-panel">
            <div class="typecho-table-wrap">
				<?php if($this->options->allowRegister): ?>
                <div class="typecho-page-title">
                    <nav class="navigation">
                        <a href="/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>tepass/signin">登录</a>
                        <a href="/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>tepass/forgot">找回密码</a>
                        <a href="/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>tepass/signup" class="active">注册</a>
                    </nav>
				</div>
				<div class="signin-up">	
					<form action="<?php $this->options->registerAction();?>" method="post" name="register" class="form">
						<input type="hidden" name="_" value="<?php echo $security->getToken($this->request->getRequestUrl());?>">
						<input type="hidden" name="referer" value="<?php $this->options->siteUrl('tepass/refresh'); ?>" />
						<ul class="typecho-option">
						  <li><input type="text" class="w-100" id="name" name="name" autocomplete="username" placeholder="请输入用户名" required></li>
						</ul>
						<ul class="typecho-option">
						  <li><input type="email" class="w-100" id="mail" name="mail" placeholder="请输入邮箱" required></li>
						</ul>
                        <ul class="typecho-option">
                           <li><input type="password" class="w-100" id="password" name="password" autocomplete="current-password" placeholder="输入密码" required></li>
                        </ul>
                        <ul class="typecho-option">
                           <li><input type="password" class="w-100" id="confirm" name="confirm" autocomplete="current-password" placeholder="再次输入密码" required></li>
                        </ul>
						<button type="submit" class="btn primary">注册</button>
					</form> 
			    </div>
				<?php else: ?>
				<div style="text-align: center; margin-top: 20px;">注册功能已关闭</div>
				<?php endif; ?>
			    <div style="clear: both"></div>
            </div>
        </div>
    </div>
</div>
<?php
include __ADMIN_DIR__ . '/common-js.php';
?>
<script>
$(document).ready(function () {
	$('#name').focus();
});
</script>
<script language="javascript">
function externallinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i=0; i<anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href"))
		anchor.target = "_self";
	}
}
window.onload = externallinks;
</script>