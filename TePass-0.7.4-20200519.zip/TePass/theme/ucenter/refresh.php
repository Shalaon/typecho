<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
include 'common.php';

//1、取uid的资料，更新vips表数据
$user=Typecho_Widget::widget('Widget_User');
if($user->uid > 0){
	$db=Typecho_Db::get ();
	$rsvips=$db->fetchRow($db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_uid=?',$user->uid)->limit(1));	

	$invcode = $rsvips['vip_refcode'];

	//1.1、更新用户的推广人数，通过vip_invcode来统计			
	$checkinvcodesql = $db->select()->from('table.tepass_vips')->where('table.tepass_vips.vip_invcode=?',$invcode);
	$rowinvcode = $db->fetchAll($checkinvcodesql);
	if(count($rowinvcode) > 0){
		$vip_refnum = count($rowinvcode);
	}else{
		$vip_refnum = 0;
	}	

	//1.2获取默认的推广收益比例，只有普通和终身会员两种
	$rsconfig=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"months_for_upgrade_eternal")->limit(1));
	if($rsvips["vip_status"] < $rsconfig['cfg_value']){
		$refrate=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"ref_rate")->limit(1));
		if(!empty($refrate['cfg_value'])){
			$ref_rate = $refrate['cfg_value'];
		}else{
			$ref_rate = "0.00";
		}
	}else{
		$refrate=$db->fetchRow($db->select()->from('table.tepass_configs')->where('table.tepass_configs.cfg_key=?',"ref_rate_for_vip")->limit(1));
		if(!empty($refrate['cfg_value'])){
			$ref_rate = $refrate['cfg_value'];
		}else{
			$ref_rate = "0.00";
		}
	}

	//更新推广人数和推广收益比例
	$sql_ref_num = $db->update('table.tepass_vips')->rows(array('vip_refnum' => $vip_refnum,'vip_ref_rate' => $ref_rate))->where('vip_uid = ?', $user->uid);
	$db->query($sql_ref_num);	


	//*****二、检测用户VIP是否到期,到期就要更新VIP状态；终身会员除外。*****
	
	//检查是否到期
	if($rsvips["vip_status"] < $rsconfig['cfg_value']){
		if(time() > $rsvips["vip_endtime"]){
			$updateVipstatus = $db->update('table.tepass_vips')->rows(array('vip_status'=>0))->where('vip_uid=?',$user->uid);
			$updateVipstatusRows= $db->query($updateVipstatus);	
		}		
	}

	//2.1更新用户的总支出vip_total_costs，单位为分
	$rstotal_cost=$db->fetchAll($db->select('fee_total_price')->from ('table.tepass_fees')->where('fee_uid=?',$user->uid)->where('fee_status=?',1)->where('fee_type < 3'));//充值或单独购买总支出
	$total_cost = 0;
	foreach($rstotal_cost as $key=>$val){
		$total_cost += $val['fee_total_price']*100;//单位为分
	}					
	$updateTotalCost = $db->update('table.tepass_vips')->rows(array('vip_total_costs'=>$total_cost))->where('vip_uid=?',$user->uid);
	$updateTotalCostRows= $db->query($updateTotalCost);	

	//2.2更新用户的推广总收益 vip_total_ref_income，单位为分
	$rstotal_income=$db->fetchAll($db->select('fee_total_price')->from ('table.tepass_fees')->join('table.tepass_vips', 'table.tepass_vips.vip_uid = table.tepass_fees.fee_uid', Typecho_Db::LEFT_JOIN)->where('vip_invcode=?',$rsvips["vip_refcode"])->where('fee_status=?',1));
	$total_income = 0;
	foreach($rstotal_income as $key=>$val){
		$total_income += $val['fee_total_price']*100;//单位为分
	}
	$total_ref_income = $total_income * $rsvips["vip_ref_rate"];//计算出总推广收益
	$total_money = (int)$rsvips["vip_points"] + (int)$total_ref_income;
	$updateTotalIncome = $db->update('table.tepass_vips')->rows(array('vip_total_income'=>(int)$total_income,'vip_total_ref_income'=>(int)$total_ref_income,'vip_money'=>(int)$total_money))->where('vip_uid=?',$user->uid);
	$updateTotalIncomeRows= $db->query($updateTotalIncome);	
	
	//数据处理完成，跳转到指定地址
	$rsredirect=$db->fetchRow($db->select()->from ('table.tepass_configs')->where('cfg_key = ?',"user_center_url")->limit(1));
	if(empty($rsredirect['cfg_value'])){
		header("Location: ".$options->adminUrl."extending.php?panel=TePass%2Ftheme%2Fucenter%2Fprofile.php"); 
	}else{
		header("Location: ".$rsredirect['cfg_value']);
	}
} else {
	header("Location: /tepass/signin");
}

include __ADMIN_DIR__ . '/common-js.php';
include __ADMIN_DIR__ . '/footer.php';
?>