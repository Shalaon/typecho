<?php
echo '	
<button onclick="show_reward()" class="btn_reward">打赏</button>
<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v='.$tepass_version.'" type="text/css" />
<script src="/usr/plugins/TePass/static/js/tepass.js?v='.$tepass_version.'" async="async"></script>
<div class="tepasspost" id="div_reward">
	<form id="tepassReward" onsubmit="return false" action="##" method="post">	
		<div class="feetype">';
		if($payRows['show_pay_type'] == "all"){ 
			echo '	
			<label  for="feetype1" onmousedown="choose_pay(1)"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" nogallery="nogallery" no-zoom="true"><span>微信支付</span></label>
			<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">
			<label  for="feetype2" onmousedown="choose_pay(2)"><img id="labe2" src="/usr/plugins/TePass/static/alipay1.png" nogallery="nogallery" no-zoom="true"><span>支付宝支付</span></label>
			<input type="radio" id="feetype2" name="feetype" value="alipay">';
		}else{		
			if($payRows['show_pay_type'] == "alipay"){
				echo '	
				<label  for="feetype2"><img id="labe2" src="/usr/plugins/TePass/static/alipay2.png" nogallery="nogallery" no-zoom="true"><span>支付宝支付</span></label>
				<input type="radio" id="feetype2" name="feetype" value="alipay" checked="checked">';
			}else{ 
				echo '	
				<label  for="feetype1"><img id="labe1" src="/usr/plugins/TePass/static/wechat2.png" nogallery="nogallery" no-zoom="true"><span>微信支付</span></label>
				<input type="radio" id="feetype1" name="feetype" value="wxpay" checked="checked">';
			}
		} 
		echo '</div>
			<div class="cl"></div>您的大名：<input type="text" id="reward_from" name="reward_from" value="匿名" placeholder="控制10个字内" required="required"/>
			<select name="reward_money" id="reward_money">
				<option value="1">1 元</option>
				<option value="5" selected="selected">5 元</option>
				<option value="10">10 元</option>
				<option value="20">20 元</option>
				<option value="50">50 元</option>
				<option value="100">100 元</option>
			</select>
			<div class="cl"></div>';
		if($is_mobie){
			echo '<input type="hidden" id="userAgent" name="userAgent" value="isMobile" />';
		}else{
			echo '<input type="hidden" id="userAgent" name="userAgent" value="isDesktop" />';
		}
		echo '	
			<input id="verifybtn" onclick="tepassReward();" οnkeydοwn="enter_down(this.form, event);" type="button" value="打赏"/>
			<input type="hidden" name="action" value="payrewardsubmit" />
			<input type="hidden" id="callback_url" name="callback_url" value="'. $callback_url .'" />
			<input type="hidden" id="feecid" name="feecid" value="'. $cid .'" />
			<input type="hidden" id="feeuid" name="feeuid" value="'. Typecho_Cookie::get('__typecho_uid') .'" />
			<input type="hidden" id="tepass_time" name="tepass_time" value="'. $tepass_time .'" />
			<input type="hidden" id="tepass_sign" name="tepass_sign" value="'. $tepass_sign .'" />
		</form>
	<div class="cl"></div>
	<span class="tips">万水千山总是情，给个打赏行不行。</span>
	<span class="tepass_top_left">打赏</span>
	<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png" nogallery="nogallery" no-zoom="true"></span>
	<div id="qrcode_box"></div><div id="bgdiv"></div>
</div>
<style type="text/css">
	#div_reward {
		display: none;
	}
	.btn_reward {
		border-style: none;
		border-radius: 5px;
		width: 80px;
		height: 30px;
		background-color: #f17425 !important;
		line-height: 30px;
		text-align: center;
		color: #FFF;
		margin: 0 auto;
		display: block;
		font-weight: normal;
	}
</style>
<script type="text/javascript">
    function show_reward (event) {
        //取消冒泡
        let oevent = event || window.event
        if (document.all) {
            oevent.cancelBubble = true
        } else {
            oevent.stopPropagation()
        }
        if (document.getElementById("div_reward").style.display === "none" || document.getElementById("div_reward").style.display === "") {
            document.getElementById("div_reward").style.display = "block"
        } else {
            document.getElementById("div_reward").style.display = "none"
        }
    }
    document.onclick = function () {
        document.getElementById("div_reward").style.display = "none"
    }
    document.getElementById("div_reward").onclick = function (event) {
        let oevent = event || window.event
        oevent.stopPropagation()
    }    
</script>';	
?>
<?php 
$user=Typecho_Widget::widget('Widget_User');
if($user->uid > 0): ?><script>document.getElementById('reward_from').value = '<?php $user->screenName(); ?>';</script><?php endif;?>