<?php
if($rowReward["fee_check"] == "pending"){
	//******感谢规则之树https://www.ruletree.club/，在0.5.0版本加入文章发布者账户收益功能******
	//通过文章id获取作者id
	$selectPost = $db->select()->from('table.contents')->where('cid=?',$rowFee["fee_cid"])->limit(1); 
	$postRows = $db->fetchRow($selectPost);

	//通过作者id查询余额并累加
	$selectUser = $db->select()->from('table.tepass_vips')->where('vip_uid=?',$postRows['authorId'])->limit(1);
	$userRows = $db->fetchRow($selectUser);
	$addAmount = $rowFee["fee_total_price"] * 100;
	$u_points = (int)$userRows['vip_points'] + (int)$addAmount;//文章收益
	$u_money = (int)$u_points + (int)$userRows['vip_total_ref_income'];

	$updateUser = $db->update('table.tepass_vips')->rows(array('vip_points'=>(int)$u_points, 'vip_money'=>(int)$u_money))->where('vip_uid=?',$postRows['authorId']);
	$updateUserRows= $db->query($updateUser);	
	//******文章发布收益算账结束******	
	//修改订单状态为checked
	$updateFeeCheck = $db->update('table.tepass_fees')->rows(array('fee_check'=>"checked"))->where('fee_id=?',$rowFee["fee_id"]);
	$updateFeeCheckRows= $db->query($updateFeeCheck);	
}
echo '	
<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v='.$tepass_version.'" type="text/css" />				
<div class="tepasspost">
	<span class="tepass_content">感谢您的打赏！</span>
	<span class="tepass_top_left">流水号：'. $rowReward["fee_id"].'</span>
	<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png" nogallery="nogallery" no-zoom="true"></span>
</div>';
?>