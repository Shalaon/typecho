<?php
$hide_notice='
<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v='.$tepass_version.'" type="text/css" />
<div class="tepasspost">
	<span class="tips">温馨提示：<a href="/tepass/signin">登录</a>后可阅读隐藏的内容。</span>
	<span class="tepass_top_left">登录可见</span>
	<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png" nogallery="nogallery" no-zoom="true"></span>
</div>';
$html = str_replace($hide_content[0], $hide_notice, $html);
?>