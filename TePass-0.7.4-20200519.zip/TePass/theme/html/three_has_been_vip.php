<?php
$html = str_replace($hide_content[0], '
<link rel="stylesheet" href="/usr/plugins/TePass/static/css/style.css?v='.$tepass_version.'" type="text/css" />
<div class="tepasspost">
	<span class="tepass_content">'.$hide_content[1][0].'</span>
	<span class="tepass_top_left"><span>VIP会员可见</span></span>
	<span class="tepass_top_right"><img src="/usr/plugins/TePass/static/icon.png" nogallery="nogallery" no-zoom="true"></span>
</div>', $html);	
?>