CREATE TABLE IF NOT EXISTS `typecho_tepass_fees` (
  `fee_id` varchar(32) NOT NULL,
  `fee_uid` int(11) DEFAULT NULL,
  `fee_cid` int(11) NOT NULL DEFAULT '0' COMMENT '文章ID',
  `fee_type` tinyint(2) DEFAULT NULL COMMENT '1.购买会员，2单独付费，3、打赏，7.退款，9.提现',
  `fee_title` varchar(255) DEFAULT NULL,
  `fee_total_price` decimal(10,2) DEFAULT NULL,
  `fee_check` VARCHAR(16) DEFAULT NULL COMMENT '订单核对',
  `fee_total_days` int(8) NOT NULL COMMENT '总天数',
  `fee_pay_type` varchar(10) NOT NULL COMMENT '支付方式',
  `fee_status` tinyint(1) DEFAULT NULL,
  `fee_remark` text COMMENT '备注',
  `fee_intime` datetime DEFAULT NULL,
  `fee_uptime` datetime DEFAULT NULL,
  `fee_cookie` varchar(255) DEFAULT NULL,
  `fee_ip` varchar(64) DEFAULT NULL COMMENT '提交订单的IP地址',
  `fee_user_agent` varchar(255) DEFAULT NULL COMMENT '提交订单的客户端',
  PRIMARY KEY  (fee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `typecho_tepass_vips`(
  `vip_id` int(11) NOT NULL AUTO_INCREMENT,
  `vip_uid` int(11) DEFAULT NULL,
  `vip_username` varchar(50) DEFAULT NULL,
  `vip_nickname` varchar(50) DEFAULT NULL,
  `vip_email` varchar(50) DEFAULT NULL,
  `vip_sckey` varchar(255) DEFAULT NULL COMMENT 'Server酱密钥',
  `vip_endtime` int(11) DEFAULT NULL COMMENT '到期时间',
  `vip_status` tinyint(2) DEFAULT '0' COMMENT '0.普通会员；1.月会员；12.年会员；60.终身会员',
  `vip_money` int(11) DEFAULT '0' COMMENT '账户余额，单位分',
  `vip_points` int(11) DEFAULT '0' COMMENT '总积分',
  `vip_invcode` varchar(8) DEFAULT NULL COMMENT '被谁邀请来的',
  `vip_refcode` varchar(8) DEFAULT NULL COMMENT '推广码',
  `vip_refnum` int(11) DEFAULT '0' COMMENT '推广人数',
  `vip_total_costs` int(11) DEFAULT '0' COMMENT '总支出',
  `vip_total_income` int(11) DEFAULT '0' COMMENT '总收益',
  `vip_ref_rate` decimal(3,2) DEFAULT '0.20' COMMENT '提成利率',
  `vip_total_ref_income` int(11) DEFAULT '0' COMMENT '推广总收益',
  `fee_total_withdraw` int(11) DEFAULT '0' COMMENT '总提现',
  `vip_intime` datetime DEFAULT NULL,
  PRIMARY KEY  (vip_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `typecho_tepass_posts`(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `post_uid` int(11) NULL DEFAULT '1',
  `post_slug` varchar(150) DEFAULT NULL,
  `post_title` varchar(250) NOT NULL,
  `post_order_title` varchar(250) NOT NULL,
  `post_type` varchar(16) DEFAULT 'post',
  `post_see_type` tinyint(1) DEFAULT '0' COMMENT '0.免费；1.登录可见；2、VIP可见；3、单独付费',
  `post_islogin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需登录才能购买',
  `post_price` decimal(10,2) NOT NULL,
  `post_price_for_vip` decimal(10,2) NOT NULL,
  `post_price_for_eternal` decimal(10,2) NOT NULL,
  `post_content` text,
  `post_sold_num` int(11) DEFAULT '0' COMMENT '卖出数量',
  `post_intime` datetime DEFAULT NULL,
  PRIMARY KEY  (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `typecho_tepass_sns` (
  `moid` int(11) NOT NULL AUTO_INCREMENT,
  `platform` varchar(16) NOT NULL DEFAULT 'sina',
  `uid` int(11) NOT NULL,
  `openid` varchar(128) NOT NULL,
  `bind_time` int(11) NOT NULL,
  `expires_in` int(11) DEFAULT NULL,
  `refresh_token` datetime DEFAULT NULL,
  `authCode` varchar(32) DEFAULT NULL,
  PRIMARY KEY  (moid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `typecho_tepass_configs` (
  `cfg_id` int(8) NOT NULL,
  `cfg_name` varchar(64) DEFAULT NULL,
  `cfg_key` varchar(64) NOT NULL,
  `cfg_type` varchar(8) DEFAULT NULL,
  `cfg_value` text,
  `cfg_desc` varchar(255) DEFAULT NULL,
  `cfg_intime` datetime DEFAULT NULL,
  PRIMARY KEY  (cfg_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  
INSERT INTO `typecho_tepass_configs` (`cfg_id`, `cfg_name`, `cfg_key`, `cfg_type`, `cfg_value`, `cfg_desc`, `cfg_intime`) VALUES
(1, '免登陆时间', 'cookie_time', 'pay', '1', '不登录购买的cookie时间', '2020-02-13 13:45:30'),
(2, '支付宝APPID', 'alipay_appid', 'pay', '', '支付宝APPID', '2020-02-12 14:13:52'),
(3, '支付宝应用私钥', 'alipay_app_private_key', 'pay', '', '支付宝商户应用私钥', '2020-02-12 14:14:01'),
(4, '支付宝公钥', 'alipay_public_key', 'pay', '', '支付宝公钥', '2020-02-12 14:14:08'),
(5, '支付宝回调地址', 'alipay_notify_url', 'pay', '', '格式：https://your_domain/usr/plugins/TePass/alipay_notify_url.php', '2020-02-12 14:14:20'),
(6, 'Payjs商户ID', 'payjs_wxpay_mchid', 'pay', '', 'Payjs的商户ID', '2020-02-12 14:14:37'),
(7, 'Payjs密钥', 'payjs_wxpay_mchkey', 'pay', '', 'Payjs通信密钥', '2020-02-12 14:14:43'),
(8, 'Payjs回调地址', 'payjs_wxpay_notify_url', 'pay', '', '格式：https://your_domain/usr/plugins/TePass/wxpay_notify_url.php', '2020-02-12 14:14:52'),
(9, '显示支付方式', 'show_pay_type', 'pay', 'all', 'all：所有方式；alipay：仅支付宝；wxpay：仅微信支付。', '2020-02-12 14:15:01'),
(10, 'Server酱密钥', 'server_chan_sckey', 'pay', '', '可利用Server酱推送付款成功的消息到微信，不设置则不会发送。', '2020-02-12 14:15:16'),
(11, 'smtp邮件服务器', 'mail_smtp', 'mail', 'smtp.exmail.qq.com', 'QQ企业邮箱：smtp.exmail.qq.com；126邮箱：smtp.126.com', '2020-02-12 14:15:29'),
(12, 'smtp服务器邮箱用户名', 'mail_user', 'mail', '', '给用户发送找回密码的邮箱地址', '2020-02-12 14:15:48'),
(13, 'smtp服务器邮箱密码', 'mail_pass', 'mail', '', '给用户发送找回密码的邮件密码', '2020-02-12 14:15:57'),
(14, 'smtp服务器端口', 'mail_port', 'mail', '587', 'smtp服务器端口，25，465，587', '2020-02-12 14:15:40'),
(15, 'smtp安全类型', 'mail_secure', 'mail', 'tls', 'tls或ssl，若端口是25，此处留空即可。', '2020-02-12 14:16:31'),
(16, '月会员价格', 'vip_price_for_monthly', 'vip', '', '月会员价格', '2020-02-12 14:17:11'),
(17, '年度会员价格', 'vip_price_for_annually', 'vip', '', '年度会员价格', '2020-02-12 14:17:39'),
(18, '终身会员价格', 'vip_price_for_eternal', 'vip', '', '终身会员价格', '2020-02-12 14:17:46'),
(19, '货币昵称', 'coin_nickname', 'money', '元', '货币昵称，默认单位元。', '2020-02-12 00:00:00'),
(20, '推广收益比率', 'ref_rate', 'money', '0.15', '推广收益比率', '2020-02-12 14:16:43'),
(21, '终身会员推广收益比例', 'ref_rate_for_vip', 'money', '0.20', '终身会员推广收益比例，设置后不能更改。', '2020-02-12 14:16:55'),
(22, '最低提现额度', 'min_withdrawal', 'money', '20', '最低提现额度', '2020-02-12 00:00:00'),
(23, '个人中心通知', 'for_my_center', 'notice', '', '个人中心通知', '2020-02-12 00:00:00'),
(24, '技术支持说明', 'for_support', 'notice', '', '技术支持说明', '2020-02-12 00:00:00'),
(25, 'QQ登录', 'qq_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(26, '微博登录', 'weibo_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(27, 'GitHub登录', 'github_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(28, '微信登录', 'wechat_login', 'sns', '', '格式：appid---appsecret---callbackurl', '2020-02-12 00:00:00'),
(29, '连续续费的月数', 'months_for_upgrade_eternal', 'vvip', '60', '连续续费到这个月数，可以升级为终身会员，默认60，建议在插件启用就修改，后面不能改。', '2020-02-12 00:00:00'),
(30, '新注册用户默认分组', 'default_register_group', 'sign', 'subscriber', '管理员：administrator，编辑：editor，贡献者：contributor，关注者：subscriber，访问者：visitor。', '2020-02-12 00:00:00'),
(31, '订单查询', 'search_order', 'order', '0', '所有人可查：0，登录用户可查：1，VIP会员可查：2。', '2020-03-07 00:00:00'),
(32, '静态资源', 'css_js', 'static', 'local', '使用本地资源：local，CDN资源：cdn。', '2020-03-12 00:00:00'),
(33, '发布资源收益', 'for_post_contribute', 'post', '', '发布资源收益，填写发布地址，默认为空，不显示，谁发布的资源，收益就在谁账户。', '2020-03-12 00:00:00'),
(34, '二维码生成接口', 'for_qrcode', 'qrcode', '', '不填写，默认调用本地接口，也可以自己去找可用的公共接口。', '2020-03-31 00:00:00'),
(35, '点击付款次数限制', 'for_click_limit', 'click', '30', '同一IP在30分钟内点击付款最多次数，默认30次。', '2020-04-16 00:00:00'),
(36, '个人中心地址', 'user_center_url', 'url', '', '个人中心地址，登录注册购买会员后跳转地址，不填默认跳到后台个人中心。', '2020-05-07 00:00:00');
