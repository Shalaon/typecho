<?php
/*
 * 付费阅读是否成功的通知
 */
include '../../../config.inc.php';
$db = Typecho_Db::get();
date_default_timezone_set('Asia/Shanghai');

$feeid = isset($_POST['feeid']) ? addslashes($_POST['feeid']) : '';
$queryContent= $db->select()->from('table.tepass_fees')->where('fee_id = ?', $feeid); 
$rowContent = $db->fetchRow($queryContent);

$json=json_encode(array("feestatus"=>$rowContent['fee_status'],"feeid"=>$feeid));
echo $json;
exit;
?>